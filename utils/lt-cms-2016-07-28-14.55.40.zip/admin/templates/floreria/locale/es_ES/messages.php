<?php
define('My profile', 'Mi perfil');
define('Close session', 'Cerrar sesion');