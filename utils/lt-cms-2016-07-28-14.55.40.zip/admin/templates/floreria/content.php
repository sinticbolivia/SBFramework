<?php
lt_get_header('content');
?>
<div class="tab-content">
    <div role="tabpanel" class="tab-pane active" id="home">
  		<div id="content" class="">
			<div class="messages"><?php SB_MessagesStack::ShowMessages(); ?></div>
			<?php sb_show_module(isset($_html_content) ? $_html_content : null); ?>
			<div class="clearfix"></div>
		</div><!-- end id="content" -->  	
    </div>
</div>
<?php lt_get_footer();  ?>
