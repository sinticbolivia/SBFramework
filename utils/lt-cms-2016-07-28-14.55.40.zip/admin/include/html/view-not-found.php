<?php
?>
<h2>La vista &quot;<?php print $view_file ?>&quot; no existe</h2>