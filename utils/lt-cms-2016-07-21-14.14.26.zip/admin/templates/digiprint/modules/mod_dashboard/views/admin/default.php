<?php
?>
<div class="wrap">
	<form id="dashboard-form" action="<?php print SB_Route::_('index.php'); ?>" method="get" style="margin:250px 0 0 50px;">
		<input type="hidden" name="mod" value="" />
		<input type="hidden" name="view" value="" />
		<div class="row">
			<div class="col-xs-12 col-md-4">
				<div class="form-group">
					<input type="text" name="order_num" value="" placeholder="<?php _e('Order number', 'digiprint'); ?>" class="form-control"
						style="height:61px;text-transform: uppercase;font-size:18px;" />
				</div>
			</div>
			<div class="col-xs-12 col-md-4">
				<a href="javascript:;" class="btn btn-square btn-red" data-mod="mb" data-view="orders" >
					<img src="<?php print TEMPLATE_URL; ?>/images/icons/50x50_blancos/icon-02.png" alt="" class="icon" />
					<span class="label"><?php _e('New Order', 'digiprint'); ?></span>
				</a>
				<a href="javascript:;" class="btn btn-square btn-red" data-mod="quotes" data-view="default">
					<img src="<?php print TEMPLATE_URL; ?>/images/icons/50x50_blancos/icon-08.png" alt="" class="icon" />
					<span class="label"><?php _e('Quote', 'digiprint'); ?></span>
				</a>
				<a href="javascript:;" class="btn btn-square btn-red" data-mod="customers" data-view="default">
					<img src="<?php print TEMPLATE_URL; ?>/images/icons/50x50_blancos/icon-18.png" alt="" class="icon" />
					<span class="label"><?php _e('Customer', 'digiprint'); ?></span>
				</a>
			</div>
		</div>
	</form>
	<script>
	jQuery(function()
	{
		jQuery('.btn-square').click(function()
		{
			var form = jQuery('#dashboard-form').get(0);
			if( form.order_num.value.trim().length <= 0 )
			{
				alert('<?php _e('You need to enter the order number', 'digiprint'); ?>');
				return false;
			}
			form.mod.value = this.dataset.mod;
			form.view.value = this.dataset.view;
			jQuery('#dashboard-form').submit();
			return false;
		});
		
	});
	</script>
</div>