<?php
$tpl = SB_Request::getString('tpl_file', 'index.php');
?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title><?php lt_title(); ?></title>
	<link rel="stylesheet" href="<?php print BASEURL; ?>/js/bootstrap-3.3.5/css/bootstrap.min.css" />
	<link rel="stylesheet" href="<?php print BASEURL; ?>/js/bootstrap-3.3.5/css/bootstrap-theme.min.css" />
	<link rel="stylesheet" href="<?php print BASEURL; ?>/js/bootstrap-datepicker-1.4.0/css/bootstrap-datepicker.min.css" />
	<link rel="stylesheet" href="<?php print TEMPLATE_URL; ?>/style.css" />
	<script src="<?php print BASEURL; ?>/js/jquery.min.js"></script>
	<script src="<?php print BASEURL; ?>/js/bootstrap-3.3.5/js/bootstrap.min.js"></script>
	<script src="<?php print BASEURL; ?>/js/bootstrap-datepicker-1.4.0/js/bootstrap-datepicker.min.js"></script>
	<script src="<?php print BASEURL; ?>/js/bootstrap-datepicker-1.4.0/locales/bootstrap-datepicker.es.min.js"></script>
	<script src="<?php print BASEURL; ?>/js/common.js"></script>
	<?php lt_head(); ?>
	<script src="<?php print TEMPLATE_URL; ?>/js/common.js"></script>
</head>
<body>
<div id="container">
	<?php if( !defined('MOD_TEMPLATE') ): ?>
	<ul class="nav nav-tabs">
		<li <?php print $tpl == 'index.php' ? 'class="active"' : ''; ?>><a href="index.php">Panel</a></li>
		<li <?php print $tpl == 'inventario' ? 'class="active"' : ''; ?>><a href="index.php?tpl_file=inventario" >Inventario</a></li>
		<li <?php print $tpl == 'ventas' ? 'class="active"' : ''; ?>><a href="index.php?tpl_file=ventas" >Ventas</a></li>
		<li <?php print $tpl == 'sociales' ? 'class="active"' : ''; ?>><a href="index.php?tpl_file=sociales&mod=events" >Eventos Sociales</a></li>
		<li <?php print $tpl == 'web' ? 'class="active"' : ''; ?>><a href="index.php?tpl_file=web" >Sitio Web</a></li>
		<li <?php print $tpl == 'gestion' ? 'class="active"' : ''; ?>><a href="index.php?tpl_file=gestion" >Gestion</a></li>
		<li <?php print $tpl == 'reportes' ? 'class="active"' : ''; ?>><a href="index.php?tpl_file=reportes&mod=mb&view=reports.default" >Reportes</a></li>
		<li <?php print $tpl == 'system' ? 'class="active"' : ''; ?>><a href="index.php?tpl_file=system&mod=mb&view=settings">Sistema</a></li>
	</ul>
	<div class="tab-content">
	<?php endif; ?>
