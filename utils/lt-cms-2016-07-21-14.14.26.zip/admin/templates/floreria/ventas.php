<?php
$mod = SB_Request::getString('mod');
lt_get_header();
?>
<div role="tabpanel" class="tab-pane active" id="inventory">
	<?php if( !$mod || $mod != 'content' ): ?>
	<div class="col-md-3">
    	<a href="<?php print SB_Route::_('index.php?mod=mb&view=orders.default'); ?>" class="btn btn-default btn-lg" style="display:block;">
    		Pedidos
    	</a>
	</div>
	<div class="col-md-3">
    	<a href="<?php print SB_Route::_('index.php?mod=mb&view=pos.default'); ?>" class="btn btn-default btn-lg" style="display:block;">
    		Punto de Venta
    	</a>
	</div>
	<div class="col-md-3">
    	<a href="<?php print SB_Route::_('index.php?mod=quotes'); ?>" class="btn btn-default btn-lg" style="display:block;">
    		Cotizaciones
    	</a>
	</div>
	<div class="col-md-3">
    	<a href="<?php print SB_Route::_('index.php?mod=invoices'); ?>" class="btn btn-default btn-lg" style="display:block;">
    		Facturas
    	</a>
	</div>
	<?php else: ?>
	<div id="content" class="">
		<div class="messages"><?php SB_MessagesStack::ShowMessages(); ?></div>
		<?php sb_show_module(isset($_html_content) ? $_html_content : null); ?>
		<div class="clearfix"></div>
	</div><!-- end id="content" -->  	
	<?php endif; ?>
</div>
<?php lt_get_footer(); ?>