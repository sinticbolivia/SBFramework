<?php
$mod = SB_Request::getString('mod');
lt_get_header();
?>
<div role="tabpanel" class="tab-pane active" id="inventory">
	<?php if( !$mod || $mod != 'content' ): ?>
    <div class="col-md-3">
    		<a href="<?php print SB_Route::_('index.php?mod=mb&view=categories.default'); ?>" class="btn btn-default btn-lg" style="display:block;">
    			Categorias
    		</a>
    </div>
	<div class="col-md-3">
		<a href="<?php print SB_Route::_('index.php?mod=mb&view=types.default'); ?>" class="btn btn-default btn-lg" style="display:block;">
			Tipos de Producto
		</a>
	</div>
	<div class="col-md-3">
		<a href="<?php print SB_Route::_('index.php?mod=mb&view=mu.default'); ?>" class="btn btn-default btn-lg" style="display:block;">
			Unidades de Medida
		</a>
	</div>
	<div class="col-md-3">
    	<a href="<?php print SB_Route::_('index.php?mod=mb'); ?>" class="btn btn-default btn-lg" style="display:block;">Productos</a>
	</div>
	<div class="col-md-3">
    	<a href="<?php print SB_Route::_('index.php?mod=mb&view=purchases.default'); ?>" class="btn btn-default btn-lg" style="display:block;">Compras</a>
	</div>
	<div class="col-md-3">
    	<a href="<?php print SB_Route::_('index.php?mod=provider'); ?>" class="btn btn-default btn-lg" style="display:block;">Proveedores</a>
	</div>
	<div class="col-md-3">
    	<a href="<?php print SB_Route::_('index.php?mod=mb&view=import'); ?>" class="btn btn-default btn-lg" style="display:block;">Importar Productos</a>
	</div>
	<?php else: ?>
	<div id="content" class="">
		<div class="messages"><?php SB_MessagesStack::ShowMessages(); ?></div>
		<?php sb_show_module(isset($_html_content) ? $_html_content : null); ?>
		<div class="clearfix"></div>
	</div><!-- end id="content" -->  	
	<?php endif; ?>
</div>
<?php lt_get_footer(); ?>