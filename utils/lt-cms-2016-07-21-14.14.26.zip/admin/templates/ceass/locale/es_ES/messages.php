<?php
define('My profile', 'Mi perfil');
define('Close session', 'Cerrar sesion');
define('Stores', 'Regionales');
define('Store', 'Regional');
define('Transfers', 'Traspasos');
define('Orders', 'Ventas');
define('Sign in', 'Ingresar');
define('From Store', 'Regional Origen');
define('To Store', 'Reginal Destino');
define('-- store --', '-- regional --');
define('New Transfer', 'Nueva Transferencia');
define('You need to select a source store', 'Necesita seleccionar una reginal de origen');
define('You need to select a destination store', 'Necesita seleccionar una reginal de destino');
define('You need to select items to transfer', 'Necesita seleccionar items para la transferencia');
define('Transfers Record', 'Registro de Transferencias');
define('Payment Status', 'Estado del Pago');
define('Print Pending Payments', 'Imprimir Pagos Pendientes');