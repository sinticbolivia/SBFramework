	<footer id="footer">
	</footer>
	<div class="clearfix"></div>
</div><!-- end id="container" -->
</body>
</html>