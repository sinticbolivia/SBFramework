<?php
define('My profile', 'Mi perfil');
define('Close session', 'Cerrar sesion');
define('Sign in', 'Ingresar');
define('Sign up', 'Registro');
define('Hello %s', 'Hola %s');
define("Don't have an account?", 'No tienes cuenta?');