CREATE TABLE IF NOT EXISTS suppliers ( 
	supplier_id             INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
	supplier_name           TEXT,
	supplier_address        TEXT,
	supplier_telephone_1    TEXT,
	supplier_telephone_2    TEXT,
	supplier_city           TEXT,
	supplier_email          TEXT,
	supplier_contact_person TEXT,
	nit_ruc_nif		varchar(50),
	bank_name		varchar(250),
	bank_account		varchar(100), 
	supplier_details        TEXT,
	last_modification_date  TEXT,
	creation_date           TEXT	
);
create table if not exists products(
				product_id integer PRIMARY KEY AUTOINCREMENT NOT NULL,
				product_code varchar(100),
				product_internal_code varchar(100),
				product_name varchar(250),
				product_description text,
				product_line_id integer, 
				product_model varchar(250), 
				product_serial_number varchar(100),
				product_barcode varchar(100),
				product_cost decimal(10, 2),
				product_price decimal(10, 2),
				product_price_2 decimal(10,2),
				product_price_3 decimal(10,3),
				product_quantity integer,
				product_unit_measure varchar(100),
				store_id integer,
				author_id integer,
				status varchar(50),
				last_modification_date datetime,
				creation_date datetime
);
create table if not exists product_meta(meta_id integer primary key autoincrement not null,
					product_code varchar(100),
					meta_key varchar(100),
					meta_value text,
					last_modification_date datetime,
					creation_date datetime				
);
create table if not exists product2category(id integer PRIMARY KEY AUTOINCREMENT NOT NULL,
						product_id integer NOT NULL,
						category_id integer NOT NULL,
						creation_date datetime
);
create table if not exists product_kardex(
					id integer primary key autoincrement not null,
					product_code varchar(100),
					in_out varchar(5),
					quantity integer not null,
					quantity_balance decimal(10, 2),
					unit_price decimal(10, 2),
					total_amount decimal(10, 2),
					monetary_balance decimal(10, 2),
					transaction_type_id integer,
					author_id integer not null,
					creation_date datetime
);
CREATE TABLE IF NOT EXISTS transaction_types ( 
    transaction_type_id     INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    transaction_key         TEXT,
    transaction_name        TEXT,
    transaction_description TEXT,
    in_out                  TEXT,
    last_modification_date  TEXT,
    creation_date           TEXT 
);

create table if not exists transactions(
				transaction_id integer primary key autoincrement not null,
				transaction_code varchar(200),
				transaction_type_id integer not null,
				store_id integer not null,
				user_id integer not null,
				details text,
				sub_total decimal(10, 2),
				discount decimal(10, 2),
				total decimal(10, 2),
				status varchar(100),
				sequence integer,
				last_modification_date datetime,
				creation_date datetime
);
create table if not exists transaction_items(transaction_item_id integer primary key autoincrement not null,
					transaction_code varchar(200),
					object_id integer,
					object_code varchar(200),
					object_type varchar(200),
					object_price decimal(10, 2),
					object_quantity integer,
					sub_total decimal(10, 2),
					discount decimal(10, 2),
					total decimal(10, 2),
					notes text,						
					last_modification_date datetime,
					creation_date datetime
);
create table if not exists transaction_meta(meta_id integer primary key autoincrement not null,
					transaction_code varchar(100),
					meta_key varchar(100),
					meta_value text,
					last_modification_date datetime,
					creation_date datetime				
);
