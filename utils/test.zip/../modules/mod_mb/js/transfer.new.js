/**
 * 
 */
function SBTransfer()
{
	var item_tpl = '<tr data-id="{id}">'+
						'<td>{number}<input type="hidden" name="items[{index}][id]" value="{id}" /></td>' +
						'<td>{code}<input type="hidden" name="items[{index}][code]" value="{code}" class="form-control" /></td>' +
						'<td class="column-product">{name}<input type="hidden" name="items[{index}][name]" value="{name}" class="form-control" /></td>' +
						'<td><input type="number" min="1" name="items[{index}][qty]" value="{qty}" class="form-control item-qty" /></td>' +
						'<td><a href="javascript:;" class="remove-item btn btn-default"><span class="glyphicon glyphicon-trash"></span></a></td>' +
					'</tr>';
	var $this 	= this;
	var table	= jQuery('#purchase-table');
	var search 	= jQuery('#search_product');
	var form	= jQuery('#form-quote');
	this.ItemExists = function(id)
	{
		var result = false;
		table.find('tbody tr').each(function(i, row)
		{
			if( row.dataset.id == id )
			{
				result = row;
				return false;
			}
		});
		return result;
	};
	this.AddItem = function(item)
	{
		if( !item && search.val().trim().length <= 0 )
		{
			return false;
		}
		var exists 	= false;
		var rows 	= table.find('tbody').find('tr').length;
		var row 	= item_tpl.replace(/{index}/g, rows)
							.replace('{number}', rows + 1);
		if( item )
		{
			row = row.replace(/{id}/g, item.product_id)
						.replace(/{code}/g, item.product_code)
						.replace(/{name}/g, item.product_name)
						.replace(/{batch}/g, item.batch)
						.replace(/{qty}/g, item.use_qty)
						.replace(/{price}/g, item.product_cost)
						.replace(/{total}/g, item.product_cost);
			exists = $this.ItemExists(item.product_id);
		}
		else if( window.mb_product )
		{
			row = row.replace(/{id}/g, mb_product.id)
						.replace(/{code}/g, mb_product.product_code)
						.replace(/{name}/g, search.val())
						.replace(/{batch}/g, '')
						.replace(/{qty}/g, 1)
						.replace(/{price}/g, mb_product.product_cost)
						.replace(/{total}/g, mb_product.product_cost);
			exists = $this.ItemExists(mb_product.product_id);
		}
		
		if( exists )
		{
			//##update product qty
			var qty = jQuery(exists).find('.item-qty').val();
			qty += item ? item.use_qty : 1;
			jQuery(exists).find('.item-qty').val(qty);
			$this.CalculateRowTotal(jQuery(exists));
		}
		else
		{
			table.find('tbody').append(row);
		}
		search.val('').focus();
		$this.CalculateTotals();
	};
	this.RemoveItem = function(e)
	{
		this.parentNode.parentNode.remove();
		return false;
	};
	this.OnQtyChanged = function(e)
	{
		if( e.type == 'change' || e.type == 'keyup' )
		{
			if( e.type == 'keyup' && e.keyCode != 13 )
			{
				return false;
			}
			
			var row = jQuery(this).parents('tr:first');
			$this.CalculateRowTotal(row);
			$this.CalculateTotals();
		}
	};
	this.OnPriceChanged = function(e)
	{
		var row = jQuery(this).parents('tr:first');
		if( e.keyCode == 13 )
		{
			$this.CalculateRowTotal(row);
			$this.CalculateTotals();
			return false;
		}
		
		$this.CalculateRowTotal(row);
		$this.CalculateTotals();
		return true;
	};
	this.CalculateRowTotal = function(row)
	{
		var qty = parseInt(row.find('.item-qty:first').val());
		var price = parseFloat(row.find('.item-price:first').val());
		var tax = 0;//parseFloat(row.find('.item-tax:first').val());
		var total = (qty * price) + tax;
		row.find('.item-total:first').html(total.toFixed(2));
		
		return total;
	};
	this.CalculateTotals = function()
	{
		var rows = table.find('tbody tr');
		var subtotal = 0;
		var tax = 0;
		var total = 0;
		jQuery.each(rows, function(i, row)
		{
			subtotal += $this.CalculateRowTotal(jQuery(row));
		});
		total = subtotal;
		if( window.invoice_tax )
		{
			tax = subtotal * window.invoice_tax;
			total = subtotal + tax;
		}
		jQuery('#quote-subtotal').html(subtotal.toFixed(2));
		jQuery('#quote-tax').html(tax.toFixed(2));
		jQuery('#quote-total').html(total.toFixed(2));

		return total;
	}
	this.Save = function()
	{
		var from_store_id = jQuery('#from_store_id').val().trim();
		var to_store_id = jQuery('#to_store_id').val().trim();
		if( from.store_id.length <= 0 || from_store_id <= 0 )
		{
			alert(lt.modules.mb.locale.SOURCE_STORE_NEEDED);
			return false;
		}
		if( to.store_id.length <= 0 || to_store_id <= 0 )
		{
			alert(lt.modules.mb.locale.DESTINATION_STORE_NEEDED);
			return false;
		}
		var params = form.serialize();
		jQuery.post('index.php', params, function(res)
		{
			if( res.status == 'ok' )
			{
				alert(res.message, function(){window.location.reload();});
			}
			else
			{
				alert(res.error);
			}
		});
	};
	function setEvents()
	{
		jQuery('#from_store_id').change(function(e)
		{
			if( this.value.trim() == '' || this.value == -1 )
				return false;
			jQuery('#search_product').get(0).dataset.query_data = 'store_id=' + this.value;
		});
		jQuery('#search_product').keyup(function(e)
		{
			if( e.keyCode != 13)
				return false;
			
			$this.AddItem();
		});
		jQuery('#btn-add-item').click($this.AddItem);
		jQuery(document).on('click', '.remove-item', $this.RemoveItem);
		jQuery(document).on('keyup change keydown', '.item-qty', $this.OnQtyChanged);
		jQuery(document).on('keyup keydown', '.item-price', $this.OnPriceChanged);
		form.submit(function()
		{
			var from_store_id = jQuery('#from_store_id').val().trim();
			var to_store_id = jQuery('#to_store_id').val().trim();
			if( from_store_id.length <= 0 || parseInt(from_store_id) <= 0 )
			{
				alert(lt.modules.mb.locale.SOURCE_STORE_NEEDED);
				return false;
			}
			if( to_store_id.length <= 0 || to_store_id <= 0 )
			{
				alert(lt.modules.mb.locale.DESTINATION_STORE_NEEDED);
				return false;
			}
			if( jQuery('#purchase-table tbody tr').length <= 0 )
			{
				alert(lt.modules.mb.locale.TRANSFER_ITEMS_REQUIRED);
				return false;
			}
			return true;
		});
	};
	setEvents();
}
jQuery(function()
{
	window.mb_transfer = new SBTransfer();
	var completion = new SBCompletion({
		input: document.getElementById('search_product'),
		url: 'index.php?mod=mb&task=ajax&action=search_product',
		callback: function(sugesstion)
		{
			window.mb_product = jQuery(sugesstion).data('obj');
		}
	});
});