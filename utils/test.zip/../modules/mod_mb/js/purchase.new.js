/**
 * 
 */
function SBPurchase()
{
	var item_tpl = '<tr data-id="{id}">'+
						'<td>{number}<input type="hidden" name="items[{index}][id]" value="{id}" /></td>' +
						'<td><input type="text" name="items[{index}][code]" value="{code}" class="form-control" /></td>' +
						'<td class="column-product"><input type="text" name="items[{index}][name]" value="{name}" class="form-control" /></td>' +
						'<td><input type="number" min="1" name="items[{index}][qty]" value="1" class="form-control item-qty" /></td>' +
						'<td class="column-price"><input type="text" name="items[{index}][price]" value="{price}" class="form-control item-price text-center" /></td>' +
						'<td><span class="item-total">{total}</span></td>' +
						'<td><a href="javascript:;" class="remove-item btn btn-default"><span class="glyphicon glyphicon-trash"></span></a></td>' +
					'</tr>';
	var $this 	= this;
	var table	= jQuery('#purchase-table');
	var search 	= jQuery('#search_product');
	var form	= jQuery('#form-quote');
	this.SetItemTemplate = function(tpl)
	{
		item_tpl = tpl;
	};
	this.ItemExists = function(id)
	{
		var result = false;
		table.find('tbody tr').each(function(i, row)
		{
			if( row.dataset.id == id )
			{
				result = row;
				return false;
			}
		});
		return result;
	};
	this.AddItem = function()
	{
		if( search.val().trim().length <= 0 )
		{
			return false;
		}
		
		var rows = table.find('tbody').find('tr').length;
		var row = item_tpl.replace(/{index}/g, rows)
							.replace('{number}', rows + 1);
		//console.log(row);			
		if( window.mb_product )
		{
			row = row.replace(/{id}/g, mb_product.id)
						.replace('{code}', mb_product.product_code)
						.replace('{price}', isNaN(parseFloat(mb_product.product_cost)) ? parseFloat(0).toFixed(2) : mb_product.product_cost )
						.replace('{total}', mb_product.product_cost)
						.replace(/{name}/g, mb_product.name);
		}
		else
		{
			row = row.replace(/{id}/g, '')
						.replace('{code}', '')
						.replace('{price}', '0.00')
						.replace('{total}', '0.00')
						.replace(/{name}/g, search.val());
		}
		var exists = false;
		if( window.mb_product )
			exists = $this.ItemExists(mb_product.product_id);
		
		if( /*window.mb_product &&*/ exists )
		{
			//##update product qty
			var qty = jQuery(exists).find('.item-qty').val();
			qty++;
			jQuery(exists).find('.item-qty').val(qty);
			$this.CalculateRowTotal(jQuery(exists));
		}
		else
		{
			table.find('tbody').append(row);
		}
		window.mb_product = null;
		search.val('').focus();
		$this.CalculateTotals();
	};
	this.RemoveItem = function(e)
	{
		var row_index = jQuery(this.parentNode.parentNode).index();
		console.log(row_index);
		$this.ReOrderItems(row_index);
		this.parentNode.parentNode.remove();
		return false;
	};
	this.ReOrderItems = function(from_row)
	{
		var tr				= table.find('tbody tr').eq(from_row);
		var current_index 	= tr.index();
		var new_index 		= current_index;
		tr.nextAll().each(function(i, ntr)
		{
			var inputs = jQuery(ntr).find('input');
			inputs.each(function(ii, input)
			{
				if(input.name.indexOf('item') != -1)
				{
					input.name = input.name.replace(/\[\d+\]/, '['+new_index+']')
				}
			});
			new_index++;
		});
		//tr.remove();
		$this.CalculateTotals();
	};
	this.OnQtyChanged = function(e)
	{
		if( e.type == 'change' || e.type == 'keyup' )
		{
			if( e.type == 'keyup' && e.keyCode != 13 )
			{
				return false;
			}
			
			var row = jQuery(this).parents('tr:first');
			$this.CalculateRowTotal(row);
			$this.CalculateTotals();
		}
	};
	this.OnPriceChanged = function(e)
	{
		var row = jQuery(this).parents('tr:first');
		if( e.keyCode == 13 )
		{
			$this.CalculateRowTotal(row);
			$this.CalculateTotals();
			return false;
		}
		
		$this.CalculateRowTotal(row);
		$this.CalculateTotals();
		return true;
	};
	this.CalculateRowTotal = function(row)
	{
		var qty = parseInt(row.find('.item-qty:first').val());
		var price = parseFloat(row.find('.item-price:first').val());
		var tax = 0;//parseFloat(row.find('.item-tax:first').val());
		var total = (qty * price) + tax;
		row.find('.item-total:first').html(total.toFixed(2));
		
		return total;
	};
	this.CalculateTotals = function()
	{
		var rows = table.find('tbody tr');
		var subtotal = 0;
		var tax = 0;
		var total = 0;
		jQuery.each(rows, function(i, row)
		{
			subtotal += $this.CalculateRowTotal(jQuery(row));
		});
		total = subtotal;
		if( window.invoice_tax )
		{
			tax = subtotal * window.invoice_tax;
			total = subtotal + tax;
		}
		jQuery('#quote-subtotal').html(subtotal.toFixed(2));
		jQuery('#quote-tax').html(tax.toFixed(2));
		jQuery('#quote-total').html(total.toFixed(2));

		return total;
	}
	this.Save = function()
	{
		if(this.supplier_id.value <= 0 )
		{
			alert('Necesita seleccionar un proveedor');
			return false;
		}
		if( parseInt(this.store_id.value) <= 0 )
		{
			alert('Debe seleccionar una tienda');
			return false;
		}
		if( $this.CalculateTotals() <= 0 )
		{
			alert('Su orden de pedido no tiene monto, revise los items, precios y catidades');
			return false;
		}
		return true;
	};
	function setEvents()
	{
		jQuery('#store_id').change(function()
		{
			if( this.value == '-1' )
				return;
			jQuery('#search_product').get(0).dataset.query_data = 'store_id='+this.value;
			jQuery.get('index.php?mod=mb&task=ajax&action=get_warehouses&store_id=' +this.value, function(res)
			{
				jQuery('#warehouse_id').html('');
				jQuery('#warehouse_id').append('<option value="-1">-- almacen --</option>');
				jQuery.each(res.items, function(i, item)
				{
					jQuery('#warehouse_id').append('<option value="'+item.id+'">'+item.name+'</option>');
				});
			});
		});
		jQuery('#search_product').keyup(function(e)
		{
			if( e.keyCode != 13)
				return false;
			
			$this.AddItem();
		});
		jQuery('#btn-add-item').click($this.AddItem);
		jQuery(document).on('click', '.remove-item', $this.RemoveItem);
		jQuery(document).on('keyup change keydown', '.item-qty', $this.OnQtyChanged);
		jQuery(document).on('keyup keydown', '.item-price', $this.OnPriceChanged);
		form.submit($this.Save);
	};
	setEvents();
}
//##define the supplier search select callback
window.select_callback = function(obj)
{
	jQuery('#supplier_id').val(obj.id);
	jQuery('#supplier_name').val(obj.name);
	jQuery('#search-provider-modal').modal('hide');
};
jQuery(function()
{
	window.mb_quote = new SBPurchase();
	var completion = new SBCompletion({
		input: document.getElementById('search_product'),
		url: 'index.php?mod=mb&task=ajax&action=search_product',
		callback: function(sugesstion)
		{
			window.mb_product = jQuery(sugesstion).data('obj');
		}
	});
	jQuery('#btn-search-provider').click(function()
	{
		jQuery('#search-provider-modal iframe').get(0).contentDocument.location.reload();
		jQuery('#search-provider-modal').modal('show');
		return false;
	});
});