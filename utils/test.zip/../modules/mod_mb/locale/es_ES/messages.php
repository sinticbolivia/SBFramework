<?php
define('New Assembly', 'Nuevo Ensamblado');
define('Print Labels', 'Imprimir Etiquetas');
define('in', 'entrada');
define('out', 'salida');
define('gp_mb', 'MonoBusiness');