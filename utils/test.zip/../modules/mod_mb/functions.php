<?php
function mb_get_product_meta($id, $meta_key)
{
	return SB_Meta::getMeta('mb_product_meta', $meta_key, 'product_id', $id);
}
function mb_add_product_meta($id, $meta_key, $meta_value)
{
	return SB_Meta::addMeta('mb_product_meta', $meta_key, $meta_value, 'product_id', $id);
}
function mb_update_product_meta($id, $meta_key, $meta_value)
{
	return SB_Meta::updateMeta('mb_product_meta', $meta_key, $meta_value, 'product_id', $id);
}
function mb_delete_product_meta($id, $meta_key)
{
	return SB_Meta::deleteMeta('mb_product_meta', $meta_key, 'product_id', $id);
}
function mb_get_store_meta($id, $meta_key)
{
	return SB_Meta::getMeta('mb_store_meta', $meta_key, 'store_id', $id);
}
function mb_add_store_meta($id, $meta_key, $meta_value)
{
	return SB_Meta::addMeta('mb_store_meta', $meta_key, $meta_value, 'store_id', $id);
}
function mb_update_store_meta($id, $meta_key, $meta_value)
{
	return SB_Meta::updateMeta('mb_store_meta', $meta_key, $meta_value, 'store_id', $id);
}
function mb_delete_store_meta($id, $meta_key)
{
	return SB_Meta::deleteMeta('mb_store_meta', $meta_key, 'store_id', $id);
}
function mb_get_order_meta($id, $meta_key)
{
	return SB_Meta::getMeta('mb_order_meta', $meta_key, 'order_id', $id);
}
function mb_add_order_meta($id, $meta_key, $meta_value)
{
	return SB_Meta::addMeta('mb_order_meta', $meta_key, $meta_value, 'order_id', $id);
}
function mb_update_order_meta($id, $meta_key, $meta_value)
{
	return SB_Meta::updateMeta('mb_order_meta', $meta_key, $meta_value, 'order_id', $id);
}
function mb_delete_order_meta($id, $meta_key)
{
	return SB_Meta::deleteMeta('mb_order_meta', $meta_key, 'order_id', $id);
}
/**
 * 
 * @param unknown $title
 * @param string $subject
 * @return TCPDF
 */
function mb_get_pdf_instance($title, $subject = '', $engine = 'tcpdf')
{
	$pdf = null;
	if( $engine == 'tcpdf' )
	{
		sb_include_lib('tcpdf/tcpdf.php');
		// create new PDF document
		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
		// set document information
		$pdf->SetCreator('MonoBusiness - Sintic Bolivia');
		$pdf->SetAuthor('J. Marcelo Aviles Paco');
		$pdf->SetTitle($title);
		$pdf->SetSubject($subject);
		//$pdf->SetKeywords('TCPDF, PDF, example, test, guide');
		// set default monospaced font
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		//$pdf->SetFont('dejavusans', '', 14, '', true);
		$pdf->SetFont('freesans', '', 9, '', true);
		// set margins
		$pdf->SetMargins(4, 5, 3);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		$pdf->setPrintFooter(false);
		$pdf->setPrintHeader(false);
		// set auto page breaks
		$pdf->SetAutoPageBreak(TRUE, 10);
	}
	elseif( $engine == 'dompdf' )
	{
		sb_include_lib('dompdf/dompdf.php');
		
		$pdf = new Dompdf\Dompdf();
		$pdf->set_option('defaultFont', 'Helvetica');
		$pdf->set_option('isRemoteEnabled', true);
		$pdf->set_option('isPhpEnabled', true);
		//$pdf->set_option('defaultPaperSize', 'Legal');
		// (Optional) Setup the paper size and orientation
		$pdf->setPaper('A4'/*, 'landscape'*/);
	}
	
	return $pdf;
}
/**
 * Function to page navigation
 * 
 * @param string $order_by
 * @param Object $class -> class module
 * @param array $columns
 * @param array $table
 * @param array $where is null
 * @return array[]
 */
function sb_get_navigation($order_by, $class, array $columns, array $table, array $where = NULL, $_limit = null, $order = 'DESC')
{
	$dbh		= SB_Factory::getDbh();
	$page       = SB_Request::getInt('page', 1 );
	$limit      = SB_Request::getInt('limit', defined('ITEMS_PER_PAGE') ? ITEMS_PER_PAGE : 25);
	$query      = sprintf("SELECT {columns} FROM %s ",implode(',',$table));
	$search_by	= SB_Request::getString('search_by');
	$keyword	= SB_Request::getString('keyword');
	
	if( $_limit )
		$limit = $_limit;
	
	$_where		= "WHERE 1 = 1 ";
	if( is_array($where) )
	{
		foreach($where as $w)
		{
			$_where .= "AND $w ";
		}
		$_where = rtrim($_where, ' ');
	}
	if( $search_by && $keyword )
	{
		$_where .= " AND $search_by LIKE '%$keyword%'";
	}
	$query .= " $_where ";
	$order_query  =  "ORDER BY $order_by $order";
//var_dump(str_replace('{columns}', 'COUNT(*) AS total_rows', $query));
	$dbh->Query(str_replace('{columns}', 'COUNT(*) AS total_rows', $query));

	$total_rows   =  $dbh->FetchRow()->total_rows;
	$total_pages  =  ceil($total_rows / $limit);
	$offset       =  ($page <= 1) ? 0 : ($page - 1) * $limit;
	$limit_query  =  "LIMIT $offset, $limit";

	$query = str_replace('{columns}', implode(',', $columns), $query) . " $order_query $limit_query";
	$dbh->Query($query);
	$arreglo = array();
	foreach($dbh->FetchResults() as $row)
	{
		$a = new $class();
		$a->SetDbData($row);
		$arreglo[] = $a;
	}
	sb_set_view_var('search_by', $search_by);
	sb_set_view_var('keyword', $keyword);
	sb_set_view_var('total_pages', $total_pages);
	sb_set_view_var('current_page', $page);
	return $arreglo;
}
/**
 * Get Available order statuses
 * 
 * @return Array
 */
function mb_get_order_statuses()
{
	$statuses = array(
			'pending' 		=> __('Pending', 'mb'),
			'processing' 	=> __('Processing', 'mb'),
			'on_the_way' 	=> __('On the way', 'mb'),
			'delivered' 	=> __('Delivered', 'mb'),
			'complete' 		=> __('Complete', 'mb'),
			'cancelled'		=> __('Cancelled', 'mb')
	);
	
	return SB_Module::do_action('mb_order_statuses', $statuses);
}
function mb_get_order_payment_statuses($keys_only = false)
{
	$statuses = array(
			'pending' 		=> __('Pending', 'mb'),
			'complete' 		=> __('Complete', 'mb'),
	);
	return SB_Module::do_action('mb_order_payment_statuses', $statuses);
}
function mb_get_transfer_statuses()
{
	$statuses = array(
			'pending' 		=> __('Pending', 'mb'),
			'on_the_way' 	=> __('On the way', 'mb'),
			'delivered' 	=> __('Delivered', 'mb'),
			'complete' 		=> __('Complete', 'mb'),
			'cancelled'		=> __('Cancelled', 'mb')
	);
	
	return SB_Module::do_action('mb_transfer_statuses', $statuses);
}
/**
 * Get all available tax rates
 * 
 * @return array
 */
function mb_get_tax_rates()
{
	$dbh = SB_Factory::getDbh();
	$query = "SELECT * FROM mb_tax_rates WHERE 1 = 1 ORDER BY rate ASC";
	return $dbh->FetchResults($query);
}
/**
 * Get default tax rate
 * 
 * @return object
 */
function mb_get_default_tax()
{
	$dbh = SB_Factory::getDbh();
	$query = "SELECT * FROM mb_tax_rates WHERE is_default = 1 LIMIT 1";
	return $dbh->FetchRow($query);
}
/**
 * Register a new purchase order into database
 * 
 * @param array $data
 * @param array $items
 * @return int the purchase order id
 */
function mb_insert_purchase_order($data, $items)
{
	$dbh = SB_Factory::getDbh();
	$items 	= SB_Module::do_action('mb_before_insert_purchase_order_items', $items);
	
	if( isset($data['order_id']) && $data['order_id'] )
	{
		unset($data['creation_date']);
		$dbh->Update('mb_purchase_orders', $data, array('order_id' => $data['order_id']));
		$dbh->Delete('mb_purchase_order_items', array('order_id' => $data['order_id']));
		$id = $data['order_id'];
	}
	else 
	{
		$data['order_id'] = $id = $dbh->Insert('mb_purchase_orders', $data);
	}
	//##insert the order items
	for($i = 0; $i < count($items); $i++)
	{
		$items[$i]['order_id'] = $id;
	}
	$dbh->InsertBulk('mb_purchase_order_items', $items);
	
	SB_Module::do_action('mb_insert_purchase_order', $data, $items);
	return $id;
}
/**
 * Insert or update an order including its items and return the order id
 * 
 * @param array $data
 * @param array  $items
 * @return int $order_id
 */
function mb_insert_sale_order($data, $items)
{
	$order_id = null;
	$dbh = SB_Factory::getDbh();
	if( !isset($data['order_id']) )
	{
		SB_Module::do_action('pos_before_register_sale', $data);
		$data['sequence'] = mb_get_order_next_sequence($data['store_id']);
		$order_id = $dbh->Insert('mb_orders', $data);
		for($i = 0; $i < count($items); $i++ )
		{
			$items[$i]['order_id'] = $order_id;
		}
		//##insert order items
		$dbh->InsertBulk('mb_order_items', $items);
		SB_Module::do_action('mb_pos_after_register_sale', $order_id, $data, $items);
	}
	else
	{
		$order_id = $data['order_id'];
		unset($data['creation_date'], $data['order_id']);
		$dbh->Update('mb_orders', $data, array('order_id' => $order_id));
		$dbh->Delete('mb_order_items', array('order_id' => $order_id));
		for($i = 0; $i < count($items); $i++ )
		{
			$items[$i]['order_id'] = $order_id;
		}
		$dbh->InsertBulk('mb_order_items', $items);
		SB_Module::do_action('mb_pos_after_update_sale', $order_id, $data, $items);
	}
	return $order_id;
}
function mb_get_order_next_sequence($store_id)
{
	$query = "select MAX(sequence) + 1 
				from mb_orders
				where store_id = $store_id";
	$seq = (int)SB_Factory::getDbh()->GetVar($query);
	if( $seq <= 0 )
		$seq = 1;
	return $seq;
}