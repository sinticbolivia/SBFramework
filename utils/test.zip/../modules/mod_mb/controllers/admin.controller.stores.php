<?php
class LT_AdminControllerMbStores extends SB_Controller
{
	public function task_default()
	{
		$dbh = SB_Factory::getDbh();
		$query = "SELECT * FROM mb_stores ORDER BY creation_date DESC";
		$dbh->Query($query);
		$stores = array();
		foreach($dbh->FetchResults() as $row)
		{
			$store = new SB_MBStore();
			$store->SetDbData($row);
			$stores[] = $store;
		}
		
		sb_set_view_var('stores', $stores);
	}
	public function task_new()
	{
		$ttypes = SB_Warehouse::GetTransactionTypes();
		sb_set_view_var('ttypes', $ttypes);
		sb_set_view_var('page_title', SBText::_('Create New Store', 'mb'));
	}
	public function task_edit()
	{
		$id = SB_Request::getInt('id');
		if( !$id )
		{
			SB_MessagesStack::AddMessage(SBText::_('The store identifier is invalid'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=stores.default'));
		}
		$ttypes = SB_Warehouse::GetTransactionTypes();
		$store = new SB_MBStore($id);
		sb_set_view('stores.new');
		sb_set_view_var('ttypes', $ttypes);
		sb_set_view_var('page_title', SBText::_('Edit Store', 'mb'));
		sb_set_view_var('the_store', $store);
	}
	public function task_save()
	{
		$id 			= SB_Request::getInt('store_id');
		$store_name 	= SB_Request::getString('store_name');
		$store_address 	= SB_Request::getString('store_address');
		$phone 			= SB_Request::getString('store_phone');
		$data 			= compact('store_name', 'store_address', 'phone');
		$dbh 			= SB_Factory::getDbh();
		if( !$id )
		{
			$data['creation_date'] = date('Y-m-d');
			$id = $dbh->Insert('mb_stores', $data);
			$link = SB_Route::_('index.php?mod=mb&view=stores.default');
			$msg = SBText::_('The store has been created', 'mb');
		}
		else
		{
			$dbh->Update('mb_stores', $data, array('store_id' => $id));
			$link 	= SB_Route::_('index.php?mod=mb&view=stores.edit&id='.$id);
			$msg	= SBText::_('The store has been updated', 'mb');
		}
		foreach((array)SB_Request::getVar('meta', array()) as $meta_key => $meta_value)
		{
			mb_update_store_meta($id, $meta_key, trim($meta_value));
		}
		SB_MessagesStack::AddMessage($msg, 'success');
		sb_redirect($link);
	}
	public function task_delete()
	{
		$id = SB_Request::getInt('id');
		if( !$id )
		{
			SB_MessagesStack::AddMessage(SBText::_('The store identifier is invalid'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=stores.default'));
		}
		$store = new SB_MBStore($id);
		if( !$store->store_id )
		{
			SB_MessagesStack::AddMessage(SBText::_('The store identifier does not exists'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=stores.default'));
		}
		$dbh = SB_Factory::getDbh();
		$query = "DELETE FROM mb_store_meta WHERE store_id = $store->store_id";
		$dbh->Query($query);
		$query = "DELETE FROM mb_stores WHERE store_id = $store->store_id";
		$dbh->Query($query);
		SB_MessagesStack::AddMessage(SBText::_('The store has been deleted'), 'success');
		sb_redirect(SB_Route::_('index.php?mod=mb&view=stores.default'));
	}
}