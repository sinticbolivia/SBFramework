<?php
class LT_AdminControllerMbPos extends SB_Controller
{
	public function task_default()
	{
		$user = sb_get_current_user();
		if( !sb_is_user_logged_in() )
		{
			die(SBText::_('You need to start session', 'mb'));
		}
		if( !$user->can('mb_sell') )
		{
			SB_MessagesStack::AddMessage(SBText::_('You dont have enough permission to do this operation', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb'));
		}
		$store_id = SB_Request::getInt('store_id');
		if( !$store_id )
		{
			SB_MessagesStack::AddMessage(SBText::_('You need to select a store', 'mb'), 'info');
			$stores = SB_Warehouse::getStores();
			sb_set_view('select_store');
			sb_set_view_var('stores', $stores);
			return true;
		}
		$store = new SB_MBStore($store_id);
		if( !$store->store_id )
		{
			SB_MessagesStack::AddMessage(SBText::_('The store does not exists', 'mb'), 'error');
			return false;
		}
		$layout 	= SB_Request::getString('layout', 'list');
		$products 	= SB_Warehouse::getStoreProducts($store_id);
		$categories = SB_Warehouse::getCategories($store_id);
		//##check if cashbox is opened
		$cdate = date('Y-m-d');
		$query = "SELECT * FROM mb_cashbox WHERE cashier_id = $user->user_id AND date(today) = '$cdate' LIMIT 1";
		if( $row = $this->dbh->FetchRow($query) )
		{
			SB_Session::setVar('cashbox_id', $row->id);
		}
		//##get payment methods
		$payment_methods = array(
				(object)array(
						'key' => 'cash',
						'name'	=> SBText::_('Cash', 'mb'),
						'image_url' => MOD_MB_URL . '/images/money-icon.jpg'
				),
				(object)array(
						'key' => 'credit_card',
						'name'	=> SBText::_('Credit Card', 'mb'),
						'image_url' => MOD_MB_URL . '/images/credit-cards.jpg'
				),
				(object)array(
						'key' => 'paypal',
						'name'	=> SBText::_('Paypal', 'mb'),
						'image_url' => MOD_MB_URL . '/images/PayPal.jpg'
				)
		);
		sb_set_view_var('layout', $layout);
		sb_set_view_var('store', $store);
		sb_set_view_var('categories', $categories);
		sb_set_view_var('products', $products);
		sb_set_view_var('payment_methods', $payment_methods);
		SB_Module::add_action('lt_js_globals', array($this, 'pos_js_locale'));
		sb_add_style('pos-css', MOD_MB_URL . '/css/pos.css');
		sb_add_script(MOD_MB_URL . '/js/pos.js', 'pos-js');
		//##set the template
		$this->document->templateFile = 'module.php';
		SB_Module::do_action('mb_pos_before_show');
	}
	public function task_ajax()
	{
		$res = array();
		$user	= sb_get_current_user();
		$action = SB_Request::getString('action');
		if( $action == 'get_product' )
		{
			$id = SB_Request::getInt('id');
			$by = SB_Request::getString('by');
			$product = null;
			if( $by )
			{
				$product = SB_Warehouse::GetProductBy($by, $id);
			}
			else 
			{
				$product = new SB_MBProduct($id);
			}
			if( $product->product_id )
			{
				$res['status'] = 'ok';
				$res['product'] = $product;
			}
			else
			{
				$res['status'] = 'error';
				$res['error'] = SB_Text::_('The product does not exists', 'mb');
			}
		}
		else if( $action == 'find_customer' )
		{
			sb_include_module_helper('customers');
			$keyword = SB_Request::getString('keyword');
			if( is_numeric($keyword) )
			{
				$customer = LT_HelperCustomers::FindCustomerBy($keyword, 'nit_ruc_nif');
				if( $customer )
				{
					$customer->pending_payments = $customer->GetPayments('pending');
					$res['status'] = 'ok';
					$res['customer'] = $customer;
				}
				else 
				{
					$res['status'] = 'error';
					$res['error'] = SB_Text::_('The customer does not exists', 'mb');
				}
			}
		}
		elseif( $action == 'cash_count' )
		{
			//##get data for cash count
			$store_id	= SB_Request::getInt('store_id'); 
			$cashier 	= sb_get_current_user();
			$dbh		= SB_Factory::getDbh();
			$query 		= "SELECT SUM(total) FROM mb_orders " .
							"WHERE user_id = $cashier->user_id " .
							"AND store_id = $store_id " .
							"AND type = 'pos' " .
							"AND DATE(order_date) = CURDATE()";
			$res['status'] 		= 'ok';
			$res['total_sales']	= (float)$dbh->GetVar($query);
			if( !$res['total_sales'] )
				$res['total_sales'] = 0;
			$cdate = date('Y-m-d');
			$query = "SELECT * FROM mb_cashbox WHERE cashier_id = $user->user_id AND date(today) = '$cdate' LIMIT 1";
			$row = $this->dbh->FetchRow($query);
			if( !$row )
			{
				$res['status'] = 'error';
				$res['error'] = __('The cashbox has not been opened', 'mb');
			}
			else
			{
				$res['balance'] = $row->initial_amount;
				//##get spending
				$query = "SELECT * FROM mb_payments ".
							"WHERE store_id = $store_id ".
							"AND user_id = $user->user_id ".
							"AND ptype = 'output' ".
							"AND DATE(payment_date) = '$cdate' ".
							"ORDER BY payment_date ASC";
				$rows = $this->dbh->FetchResults($query);
				$res['total_spends'] = 0;
				foreach($rows as $_row)
				{
					$res['total_spends'] += $_row->amount; 
				}
				$res['expensed'] 	= $rows;
				$res['total_cash'] 	= ($row->initial_amount + $res['total_sales']) - $res['total_spends'];
			}
		}
		elseif( $action == 'save_cashcount' )
		{
			$cashier	= sb_get_current_user();
			$cashier_id = $cashier->user_id;
			$data		= json_encode($_POST);
			$store_id 	= SB_Request::getInt('store_id');
			$sales		= (float)SB_Request::getVar('sales');
			$spends		= (float)SB_Request::getVar('total_spends');
			$calculated	= (float)SB_Request::getVar('total_cash');
			$cash		= (float)SB_Request::getFloat('manual_balance');
			$cashbox_id = (int)SB_Session::getVar('cashbox_id');
			$diff		= $calculated - $cash;
			$data = compact('cashier_id', 'store_id', 'cashbox_id', 'sales', 'spends', 'calculated', 'cash', 'diff', 'data');
			$data['creation_date'] = date('Y-m-d H:i:s');
			if( $cashbox_id )
			{
				$id = SB_Factory::getDbh()->Insert('mb_cashcount', $data);
				$res = array('status' => 'ok', 
						'message' => __('The cashcount has been registered', 'mb'), 
						'print_link' => SB_Route::_('index.php?mod=mb&view=pos.printcashcount&id='.$id));
			}
			else
			{
				$res = array('status' => 'error', 
							'error' => __('An error ocurred while trying to register the cashcount. The cashbox has not been opened', 'mb')
				);
			}
		}
		elseif( $action == 'open_cashbox' )
		{
			$amount = SB_Request::getFloat('amount', 0);
			$notes	= SB_Request::getString('notes');
			$cdate	= date('Y-m-d');
			//##check for open cashbox
			$query = "SELECT * FROM mb_cashbox WHERE cashier_id = $user->user_id AND date(today) = '$cdate' LIMIT 1";
			if( $row = $this->dbh->FetchRow($query) )
			{
				$res = array('status' => 'error', 'error' => __('The cashbox is already open', 'mb'));
			}
			else
			{
				$data = array(
						'cashier_id'		=> $user->user_id,
						'today'				=> date('Y-m-d H:i:s'),
						'initial_amount'	=> $amount,
						'final_amount'		=> 0,
						'notes'				=> $notes,
						'status'			=> 'open'
				);
				$cashbox_id = $this->dbh->Insert('mb_cashbox', $data);
				SB_Session::setVar('cashbox_id', $cashbox_id);
				$res = array('status' => 'ok', 'message' => __('Cashbox opening was successful.', 'mb'));
			}
		}
		sb_response_json($res);
	}
	public function task_get_layout()
	{
		$store_id = SB_Request::getInt('store_id');
		$layout = SB_Request::getString('layout');
		$layout_file = MOD_MB_DIR . SB_DS . 'views' . SB_DS . 'admin' . SB_DS . 'pos_' . $layout . '_layout.php';
		if( !$store_id )
		{
			sb_response_json(array('status' => 'error', 'error' => SBText::_('The store is invalid', 'mb')));
		}
		if( !file_exists($layout_file) )
		{
			sb_response_json(array('status' => 'error', 'error' => SBText::_('The pos layout does not exists', 'mb'), 'file' => $layout_file));
		}
		$products = SB_Warehouse::getStoreProducts($store_id);
		ob_start();
		require_once $layout_file;
		$res = array('status' => 'ok', 'html' => ob_get_clean());
		sb_response_json($res);
	}
	public function task_register_sale()
	{
		if( !sb_is_user_logged_in() )
		{
			sb_response_json(array('status' => 'error', 'error' => SBText::_('You need to start a session', 'mb')));
		}
		if( !sb_get_current_user()->can('mb_sell') )
		{
			sb_response_json(array('status' => 'error', 'error' => SBText::_('You dont have enough permission to complete this operation', 'mb')));
		}
		
		$store_id 		= SB_Request::getInt('store_id');
		$nit			= SB_Request::getString('nit_ruc_nif');
		$customer 		= SB_Request::getString('customer');
		$customer_id 	= SB_Request::getInt('customer_id');
		$products 		= (array)SB_Request::getVar('products');
		$tax_percent	= SB_Request::getFloat('tax_percent');
		$notes			= SB_Request::getString('notes');
		$payment_status = SB_Request::getString('payment_status', 'complete');
		$dbh = SB_Factory::getDbh();
		$customer_created = false;
		$c_query			= '';
		if( !is_array($products) || empty($products) )
		{
			sb_response_json(array('status' => 'error', 'error' => SBText::_('You need to select items for the order.', 'mb')));
		}
		if( empty($customer) )
		{
			sb_response_json(array('status' => 'error', 'error' => SBText::_('You need to enter a customer name', 'mb')));
		}
		if( $customer_id > 0)
		{
			//##update the nit
			SB_Meta::updateMeta('mb_customer_meta', '_nit_ruc_nif', $nit, 'customer_id', $customer_id);
			SB_Meta::updateMeta('mb_customer_meta', '_last_sale_name', $customer, 'customer_id', $customer_id);
			SB_Meta::updateMeta('mb_customer_meta', '_billing_name', $customer, 'customer_id', $customer_id);
		}
		else
		{
			//##try to find the customer into database
			$c_query = "SELECT c.* ". 
						"FROM mb_customers c, mb_customer_meta cm ".
						"WHERE c.customer_id = cm.customer_id ".
						"AND cm.meta_key = '_nit_ruc_nif' " . 
						"AND cm.meta_value = '$nit' ".
						"LIMIT 1";
			$c_row = $this->dbh->FetchRow($c_query);
			//##if customer does not exists, create a new one
			if( !$c_row )
			{
				$cnames = explode(' ', $customer); 
				$lnames = '';
				if( isset($cnames[1]) )
				{
					for($_i = 1; $_i < count($cnames); $_i++)
					{
						$lnames .= "{$cnames[$_i]} ";
					}
				}
				//##create the customer
				$customer_data = array(
						'store_id'					=> $store_id,
						'first_name'				=> $cnames[0],
						'last_name'					=> $lnames,
						'company'					=> $customer,
						'last_modification_date'	=> date('Y-m-d H:i:s'),
						'creation_date'				=> date('Y-m-d H:i:s')
				);
				$customer_id = $dbh->Insert('mb_customers', $customer_data);
				SB_Meta::addMeta('mb_customer_meta', '_nit_ruc_nif', $nit, 'customer_id', $customer_id);
				SB_Meta::addMeta('mb_customer_meta', '_last_sale_name', $customer, 'customer_id', $customer_id);
				SB_Meta::addMeta('mb_customer_meta', '_billing_name', $customer, 'customer_id', $customer_id);
				$customer_created = true;
			}
			else
			{
				$customer_id = $c_row->customer_id;
				SB_Meta::updateMeta('mb_customer_meta', '_billing_name', $customer, 'customer_id', $customer_id);
				SB_Meta::updateMeta('mb_customer_meta', '_last_sale_name', $customer, 'customer_id', $customer_id);
				SB_Meta::updateMeta('mb_customer_meta', '_nit_ruc_nif', $nit, 'customer_id', $customer_id);
			}
		}
		$cdate 			= date('Y-m-d H:i:s');
		$order_items 	= array();
		$order_subtotal = 0;
		$order_total 	= 0;
		$order_tax 		= 0;
		$total_items 	= 0;
		//print_r($products);die();
		foreach($products as $p)
		{
			$price = (float)trim($p['price']);
			$item = array(
					'product_id' 				=> (int)$p['id'],
					'order_id'					=> null,
					'name'						=> $p['name'],
					'quantity'					=> (int)$p['qty'],
					'price'						=> $price,
					'subtotal'					=> (int)$p['qty'] * $price,
					'total'						=> (int)$p['qty'] * $price,
					'status'					=> 'pending',
					'last_modification_date' 	=> $cdate,
					'creation_date'				=> $cdate
			);
			$item = SB_Module::do_action('mb_build_order_item', $item, $p);
			$total_items 	+= $item['quantity'];
			$order_items[] 	= $item;
			$order_subtotal += $item['total'];
		}
		//print_r($order_items);die();
		$order_tax 		= ($tax_percent > 0) ? $order_subtotal * $tax_percent : 0;
		$order_total 	= $order_tax + $order_subtotal;
		
		$data = array(
				'store_id' 					=> $store_id,
				'transaction_type_id'		=> (int)mb_get_store_meta($store_id, '_sale_tt_id'),
				'items'						=> $total_items,
				'subtotal'					=> $order_subtotal,
				'total_tax'					=> $order_tax,
				'discount'					=> 0,
				'total'						=> $order_total,
				'details'					=> $notes,
				//'status'					=> 'complete',
				'payment_status'			=> $payment_status,
				'user_id'					=> sb_get_current_user()->user_id,
				'customer_id'				=> $customer_id,
				'order_date'				=> $cdate,
				'type'						=> 'pos',
				'last_modification_date'	=> $cdate,
				'creation_date'				=> $cdate
		);
		
		//##create order/sale
		$order_id = mb_insert_sale_order($data, $order_items);
		//##insert order meta
		$meta = (array)SB_Request::getVar('meta', array());
		foreach($meta as $meta_key => $meta_value)
		{
			SB_Meta::updateMeta('mb_order_meta', $meta_key, trim($meta_value), 'order_id', $order_id);
		}
		$data['order_id'] = $order_id;
		$order = new SB_MBOrder();
		$order->SetDbData($data);
		$order->Complete();
		SB_Module::do_action('mb_pos_register_sale', $order_id, $data, $order_items);
		$res = array('status' 				=> 'ok', 
						'message' 			=> SBText::_('The sale has been registered', 'mb'), 
						'order_id' 			=> $order_id,
						'customer_created' 	=> $customer_created,
						'customer_id'		=> $customer_id,
						'customer_query'	=> $c_query,
		);
		$res = SB_Module::do_action('mb_pos_sale_response', $res);
		sb_response_json($res);
	}
	public function task_get_products()
	{
		$store_id	= SB_Request::getInt('store_id');
		$page 		= SB_Request::getInt('page');
		$products 	= SB_Warehouse::getStoreProducts($store_id, $page);
		$html = '';
		ob_start();
		$i = 1;
		foreach($products as $p)
		{
			include MOD_MB_DIR . SB_DS . 'views' . SB_DS . 'admin' . SB_DS . 'product_row.php';
			$i++;
		}
		$html = ob_get_clean();
		sb_response_json(array('status' => 'ok', 'items' => $html));
	}
	public function task_search_product()
	{
		$store_id		= SB_Request::getInt('store_id');
		$category_id 	= SB_Request::getInt('category_id');
		$keyword 		= SB_Request::getString('keyword');
		$limit_items 	= 50;//defined('ITEMS_PER_PAGE') ? ITEMS_PER_PAGE : 25;
		$prefix		= null;
		$limit = '';
		if( !empty($keyword) )
		{
			$prefix = 'name'; 
		}
		else
		{
			$limit = "LIMIT $limit_items";
		}
		//##check if keyword has prefix
		if( strstr($keyword, '::') )
		{
			$parts = explode('::', $keyword);
			$prefix = $parts[0];
			$keyword = isset($parts[1]) ? trim($parts[1]) : '';
		}
		
		$query = "SELECT p.* 
					FROM mb_products p ";
		if( $category_id > 0 )
		{
			$query .= ", mb_product2category p2c ";
		}
		$query .= "WHERE 1 = 1 ";
		if( $category_id > 0 )
		{
			$query .= "AND p.product_id = p2c.product_id AND p2c.category_id = $category_id "; 
		}
		$query .= "AND p.store_id = $store_id ";
		
		if( $prefix == __('id', 'mb') )
		{
			$keyword = (int)$keyword;
			$query .= "AND product_id = $keyword ";
		}
		elseif( $prefix == __('code', 'mb') )
		{
			$query .= "AND product_code LIKE '%$keyword%' ";
		}
		else
		{
			$query .= "AND product_name LIKE '%$keyword%' ";
		}
					
		$query .= "ORDER BY creation_date DESC $limit";
		$dbh = SB_Factory::getDbh();
		$products = $dbh->FetchResults($query);
		$tpl = SB_Request::getString('layout', 'list') == 'list' ? MOD_MB_DIR . SB_DS . 'views' . SB_DS . 'admin' . SB_DS . 'product_row.php' : 
														MOD_MB_DIR . SB_DS . 'views' . SB_DS . 'admin' . SB_DS . 'grid_item.php';
		ob_start();
		$i = 1;
		foreach($products as $row)
		{
			$p = new SB_MBProduct();
			$p->SetDbData($row);
			include $tpl;
			$i++;
		}
		$html = ob_get_clean() . '<div class="clearfix"></div>';
		sb_response_json(array('status' => 'ok', 'items' => $html, 'total' => count($products)));
		
	}
	public function pos_js_locale($globals)
	{
		$globals['modules']['mb']['locale'] = array(
				'CUSTOMER_BLOCKED'				=> __('The customer is blocked', 'mb'),
				'CUSTOMER_HAS_PENDING_PAYMENTS' => __('The customer has pending payments', 'mb'),
				'CUSTOMER_IS_BLOCKED'			=> __('The customer is blocked', 'mb'),
				'NEED_TO_SELECT_STORE'			=> __('You need to select a store', 'mb'),
				'THE_PRODUCT_HAS_NO_PRICE'		=> __('The product has no price or is cero', 'mb'),
				'NIT_RUC_NIF_EMPTY'				=> __('You need to enter a NIT for customer', 'mb'),
				'ERROR_CUSTOMER_EMPTY'			=> __('You need to enter a customer name', 'mb'),
				'ERROR_INVOICE_NAME_EMPTY'		=> __('You need to enter the invoice name', 'mb'),
				'ERROR_SELECT_STORE'			=> __('You need to select a store', 'mb'),
				'ERROR_SELECT_SALE_TYPE'		=> __('You need to select a sale type', 'mb'),
				'ERROR_PRODUCT_WO_STOCK'		=> __('The product has no enough stock for sale', 'mb')
		);
		return $globals;
	}
	public function task_retail()
	{
		SB_Module::add_action('lt_js_globals', array($this, 'pos_js_locale'));
		$user = sb_get_current_user();
		if( !$user->can('mb_sell') )
		{
			lt_die(__('You dont have enough permission to sell products', 'mb'));
		}
		
		$this->_stores = SB_Warehouse::GetUserStores($user);
		$title = __('Sales', 'mb');
		sb_set_view_var('user', $user);
		$this->document->SetTitle($title);
	}
	public function task_printcashcount()
	{
		$id = SB_Request::getInt('id');
		$query = "SELECT * FROM mb_cashcount WHERE id = $id LIMIT 1";
		$cashcount = $this->dbh->FetchRow($query);
		$cashcount->data = json_decode($cashcount->data);
		//##get sales
		$query = "SELECT * FROM mb_orders 
					WHERE DATE(order_date) = '".sb_format_date($cashcount->creation_date, 'Y-m-d')."' 
					AND status = 'complete'
					ORDER BY order_date ASC";
		$sales = $this->dbh->FetchResults($query);
		//##get expensed
		$query = "SELECT * FROM mb_payments WHERE user_id = $cashcount->cashier_id 
					AND DATE(payment_date) = '".sb_format_date($cashcount->creation_date, 'Y-m-d')."'
					ORDER BY payment_date ASC";
		$expensed = $this->dbh->FetchResults($query);
		ob_start();
		include MOD_MB_DIR . SB_DS . 'templates/cashbox.php';
		$html = ob_get_clean();
		$pdf = mb_get_pdf_instance('', '', 'dompdf');
		$pdf->loadHtml($html);
		$pdf->render();
		$pdf->stream(sprintf(__('cashcount-%d.pdf', 'mb'), $cashcount->id),
				array('Attachment' => 0, 'Accept-Ranges' => 1));
		die();
	}
}