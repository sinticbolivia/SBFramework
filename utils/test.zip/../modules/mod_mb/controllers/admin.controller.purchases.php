<?php
class LT_AdminControllerMbPurchases extends SB_Controller
{
	public function task_default()
	{
		$query = "SELECT o.*, (SELECT store_name FROM mb_stores s WHERE s.store_id = o.store_id) AS store_name,
					(SELECT supplier_name FROM mb_suppliers as s WHERE s.supplier_id = o.supplier_id) as provider
					FROM mb_purchase_orders o 
					ORDER BY order_date DESC";
		$purchases = $this->dbh->FetchResults($query);
		sb_set_view_var('purchases', $purchases);
	}
	public function task_new()
	{
		$user = sb_get_current_user();
		if( !$user->can('mb_can_create_purchase') )
		{
			lt_die(__('You dont have enough permission to create purchases', 'mb'));
		}
		if( !$user->IsRoot() && !(int)$user->_store_id )
		{
			lt_die(__('You dont have any store assigned', 'mb'));
		}
		$user_store = $user->IsRoot() ? null : new SB_MBStore($user->_store_id);
		sb_add_script(BASEURL . '/js/sb-completion.js', 'sb-completion');
		sb_add_script(MOD_MB_URL . '/js/purchase.new.js', 'sb-purchase', 0, true);
		$title = __('New Purchase Order', 'mb');
		
		sb_set_view_var('title', $title);
		sb_set_view_var('stores', SB_Warehouse::GetUserStores($user));
		sb_set_view_var('ttypes', SB_Warehouse::GetTransactionTypes('in'));
		sb_set_view_var('user_store', $user_store);
		$this->document->SetTitle($title);
	}
	public function task_edit()
	{
		$user = sb_get_current_user();
		if( !$user->can('mb_can_edit_purchase') )
		{
			SB_MessagesStack::AddMessage(__('You dont have enough permission to complete this operation', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=purchases.default'));
		}
		$user_store = $user->IsRoot() ? null : new SB_MBStore($user->_store_id);
		$id = SB_Request::getInt('id');
		$purchase = new SB_MBPurchase($id);
		sb_set_view('purchases.new');
		//$this->SetView('purchases.new');
		$title = __('Edit Purchase Order', 'mb');
		sb_add_script(BASEURL . '/js/sb-completion.js', 'sb-completion');
		sb_add_script(MOD_MB_URL . '/js/purchase.new.js', 'sb-purchase', 0, true);
		sb_set_view_var('title', $title);
		sb_set_view_var('purchase', $purchase);
		sb_set_view_var('stores', SB_Warehouse::getUserStores($user));
		sb_set_view_var('user_store', $user_store);
		$id = SB_Request::getInt('id');
	}
	public function task_save()
	{
		if( !sb_get_current_user()->can('mb_can_create_purchase') )
		{
			SB_MessagesStack::AddMessage(__('You dont have enough permission to complete this operation', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=purchases.default'));
		}
		$order_id 				= SB_Request::getInt('purchase_id');
		$supplier_id			= SB_Request::getInt('supplier_id');
		$supplier_name			= SB_Request::getString('supplier_name');
		$store_id				= SB_Request::getInt('store_id');
		$warehouse_id			= SB_Request::getInt('warehouse_id');
		$transaction_type_id	= SB_Request::getInt('transaction_type_id');
		$order_date				= SB_Request::getDate('order_date');
		$details				= SB_Request::getString('notes');
		
		//##get latest sequence number
		$query = "SELECT MAX(sequence) + 1 FROM mb_purchase_orders WHERE store_id = $store_id";
		$sequence = $this->dbh->GetVar($query);
		if( !$sequence )
			$sequence = 1;
		$store = new SB_MBStore($store_id);
		$data = array(
				'code'					=> '',
				'name'					=> '',
				'store_id'				=> $store_id,
				'warehouse_id'			=> $warehouse_id,
				'supplier_id'			=> $supplier_id,
				'transaction_type_id'	=> $transaction_type_id ? $transaction_type_id : $store->_purchase_tt_id,
				'sequence'				=> $sequence,
				'items'					=> 0,
				'subtotal'				=> 0,
				'total_tax'				=> 0,
				'discount'				=> 0,
				//'total'					=> $total,
				'details'				=> $details,
				'status'				=> 'waiting_stock',
				'user_id'				=> sb_get_current_user()->user_id,
				'order_date'			=> $order_date,
				'delivery_date'			=> null,
				'last_modification_date'=> date('Y-m-d H:i:s')
		);
		//##calculate totals
		$total = 0;
		$subtotal = 0;
		$total_tax = 0;
		$total_items = 0;
		$order_items = array();
		foreach(SB_Request::getVar('items') as $item)
		{
			$item_total 	= $item['qty'] * (float)$item['price'];
			$total 			+= $item_total;
			$total_items 	+= $item['qty'];
			$order_items[] 	= array(
					'product_id'		=> $item['id'],
					'name'				=> $item['name'],
					'quantity'			=> $item['qty'],
					'supply_price'		=> (float)$item['price'],
					'subtotal'			=> $item_total,
					'total'				=> $item_total,
					'status'			=> 'waiting_stock',
					'last_modification_date'	=> date('Y-m-d H:i:s'),
					'creation_date'		=> date('Y-m-d H:i:s')
			);
		}
		$data['subtotal']	= $total;
		$data['total']		= $total;
		$data['items']		= $total_items;
		
		if( !$order_id )
		{
			$data['creation_date'] = date('Y-m-d H:i:s');	
			$link = SB_Route::_('index.php?mod=mb&view=purchases.edit&id=');
			$msg = __('The purchase order has been registered', 'mb');
		}
		else 
		{
			$data['order_id']	= $order_id;
			$link = SB_Route::_('index.php?mod=mb&view=purchases.edit&id=');
			$msg = __('The purchase order has been updated', 'mb');
		}
		$order_id = mb_insert_purchase_order($data, $order_items);
		$link .= $order_id;
		
		foreach(SB_Request::getVar('meta') as $meta_key => $meta_value)
		{
			SB_Meta::updateMeta('mb_purchase_order_meta', $meta_key, trim($meta_value), 'order_id', $order_id);
		}
		SB_MessagesStack::AddMessage($msg, 'success');
		sb_redirect($link);
	}
	public function task_receive()
	{
		if( !sb_get_current_user()->can('mb_can_receive_stock') )
		{
			SB_MessagesStack::AddMessage(__('You dont have enough permission to complete this operation', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=purchases.default'));
		}
		set_time_limit(0);
		$id = SB_Request::getInt('id');
		$purchase = new SB_MBPurchase($id);
		if( !$purchase->order_id )
		{
			SB_MessagesStack::AddMessage(__('The purchase order does not exists.', 'mb'), 'error');
			sb_redirect(isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : SB_Route::_('index.php?mod=mb&view=purchases.default'));
		}
		if( $purchase->status == 'complete' )
		{
			SB_MessagesStack::AddMessage(__('The purchase order is already completed.', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=purchases.default'));
		}
		$purchase->UpdateStock(sb_get_current_user()->user_id);
		
		//##call hooks
		SB_Module::do_action('mb_purchase_order_receive', $purchase);
		SB_MessagesStack::AddMessage(__('The purchase order has been completed', 'mb'), 'success');
		sb_redirect(SB_Route::_('index.php?mod=mb&view=purchases.edit&id='.$purchase->order_id));
	}
	public function task_print()
	{
		if( !sb_get_current_user()->can('mb_can_print_purchase') )
		{
			SB_MessagesStack::AddMessage(__('You dont have enough permission to complete this operation', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=purchases.default'));
		}
		$id 		= SB_Request::getInt('id');
		$purchase 	= new SB_MBPurchase($id);
		if( !$purchase->order_id )
		{
			SB_MessagesStack::AddMessage(__('The purchase order does not exists', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=purchases.default'));
		}
		ob_start();
		include SB_Module::do_action('mb_purchase_order_note_tpl', MOD_MB_DIR . SB_DS . 'templates' . SB_DS . 'purchase.order.php');
		$html = ob_get_clean();
		if( SB_Request::getInt('pdf') )
		{
			$pdf = mb_get_pdf_instance('', '', 'dompdf');
			$pdf->loadHtml($html);
			$pdf->render();
			$pdf->stream(sprintf(__('purchase-order-%d-%d.pdf', 'mb'), $purchase->order_id, $purchase->sequence),
					array('Attachment' => 0, 'Accept-Ranges' => 1));
			die();
		}
		sb_set_view('print.preview');
		sb_set_view_var('purchase', $purchase);
		sb_set_view_var('back_link', SB_Route::_('index.php?mod=mb&view=purchases.edit&id='.$purchase->order_id));
		sb_set_view_var('print_content', $html);
	}
	public function task_delete()
	{
		if( !sb_get_current_user()->can('mb_can_delete_purchase') )
		{
			SB_MessagesStack::AddMessage(__('You dont have enough permission to complete this operation', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=purchases.default'));
		}
		$id = SB_Request::getInt('id');
		$purchase = new SB_MBPurchase($id);
		if( !$purchase->order_id )
		{
			SB_MessagesStack::AddMessage(__('The purchase order does not exists', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=purchases.default'));
		}
		if( $purchase->status == 'complete' )
		{
			SB_MessagesStack::AddMessage(__('You cant delete this order', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=purchases.default'));
		}
		/*
		$this->dbh->Delete('mb_purchase_order_items', array('order_id' => $purchase->order_id));
		$this->dbh->Delete('mb_purchase_orders', array('order_id' => $purchase->order_id));
		*/
		$this->dbh->Update('mb_purchase_orders', array('status' => 'deleted'), array('order_id' => $purchase->order_id));
		SB_Module::do_action('mb_purchase_order_deleted', $purchase);
		SB_MessagesStack::AddMessage(__('The purchase order has been deleted', 'mb'), 'success');
		sb_redirect(SB_Route::_('index.php?mod=mb&view=purchases.default'));
	}
}