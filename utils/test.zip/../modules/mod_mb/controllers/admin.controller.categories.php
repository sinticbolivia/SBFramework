<?php
class LT_AdminControllerMbCategories extends SB_Controller
{
	public function task_default()
	{
		$keyword = SB_Request::getString('keyword');
		
		$dbh = SB_Factory::getDbh();
		$query = "SELECT c.*, s.store_id,s.store_name 
					FROM mb_categories c
					LEFT JOIN mb_stores s ON s.store_id = c.store_id ";
		$query .= "WHERE 1 = 1 ";
		if( !empty($keyword) )
		{
			$query .= "AND c.name LIKE '%$keyword%' ";
		} 
		$query .= "ORDER BY creation_date DESC";
		$dbh->Query($query);
		$categories = $dbh->FetchResults();
		sb_set_view_var('categories', $categories);
	}
	public function task_new()
	{
		$categories = SB_Warehouse::getCategories();
		$stores = SB_Warehouse::getStores();
		sb_set_view_var('page_title', SBText::_('Create New Category', 'mb'));
		sb_set_view_var('stores', $stores);
		sb_set_view_var('categories', array());
	}
	public function task_edit()
	{
		$id = SB_Request::getInt('id');
		if( !$id )
		{
			SB_MessagesStack::AddMessage(SBText::_('The category identifier is invalid', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=categories.default'));
		}
		$category = new SB_MBCategory($id);
		if( !$category->category_id )
		{
			SB_MessagesStack::AddMessage(SBText::_('The category identifier does not exists', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=categories.default'));
		}
		$categories	= SB_Warehouse::getCategories($category->store_id);
		$stores 	= SB_Warehouse::getStores();
		sb_set_view('categories.new');
		sb_set_view_var('page_title', SBText::_('Create New Category', 'mb'));
		sb_set_view_var('stores', $stores);
		sb_set_view_var('categories', $categories);
		sb_set_view_var('the_cat', $category);
	}
	public function task_save()
	{
		$id 			= SB_Request::getInt('cat_id');
		$name 			= SB_Request::getString('category_name');
		$description 	= SB_Request::getString('description');
		$store_id		= SB_Request::getInt('store_id');
		$parent			= SB_Request::getInt('parent_id');
		if( $parent < 0 )
			$parent = 0;
		$data = compact('name', 'description', 'store_id', 'parent');
		$dbh = SB_Factory::getDbh();
		$msg = $link = null;
		if( !$id )
		{
			$data['creation_date'] = date('Y-m-d');
			$id = $dbh->Insert('mb_categories', $data);
			$msg = SBText::_('The category has been created', 'mb');
			$link = SB_Route::_('index.php?mod=mb&view=categories.default');
		}
		else
		{
			$this->dbh->Update('mb_categories', $data, array('category_id' => $id));
			$msg = SBText::_('The category has been updated', 'mb');
			$link = SB_Route::_('index.php?mod=mb&view=categories.edit&id='.$id);
		}
		SB_MessagesStack::AddMessage($msg, 'success');
		sb_redirect($link);
	}
	public function task_delete()
	{
		$id = SB_Request::getInt('id');
		if( !$id )
		{
			SB_MessagesStack::AddMessage(SBText::_('The category identifier is invalid', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=categories.default'));
		}
		$category = new SB_MBCategory($id);
		if( !$category->category_id )
		{
			SB_MessagesStack::AddMessage(SBText::_('The category identifier does not exists', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb&view=categories.default'));
		}
		$dbh = SB_Factory::getDbh();
		$query = "DELETE FROM mb_categories WHERE category_id = $category->category_id";
		$dbh->Query($query);
		$query = "DELETE FROM mb_product2category WHERE category_id = $category->category_id";
		$dbh->Query($query);
		SB_MessagesStack::AddMessage(SBText::_('The category has been deleted', 'mb'), 'success');
		sb_redirect(SB_Route::_('index.php?mod=mb&view=categories.default'));
	}
	public function task_get_store_categories()
	{
		$store_id = SB_Request::getInt('store_id');
		$cats = SB_Warehouse::getCategories($store_id);
		$res = array('status' => 'ok', 'ops' => '');
		$res['ops'] .= '<option value="-1">'.SBText::_('-- parent category --').'</option>';
		foreach($cats as $c)
		{
			$res['ops'] .= '<option value="'.$c->category_id.'">'.$c->name.'</option>';
		}
		header('Content-type: application/json');
		die(json_encode($res));
	}
}