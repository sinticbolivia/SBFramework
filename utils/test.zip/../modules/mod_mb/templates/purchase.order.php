<?php
?>
<style>
.purchase-order{font-size:11px;font-family:Helvetica, Verdana, Arial;}
.text-center{text-align:center;}
.col-num,.col-code,.col-product,.col-price,.col-total,.col-qty{border:1px solid #000;padding:2px;}
.col-num{text-align:center;}
.col-price,.col-total{text-align:right;}
.col-qty{text-align:center;}
.bg-color{background-color:#61B061 !important;color:#fff !important;}
.total{text-align:right;padding:2px;border:1px solid #000;background-color:#61B061;color:#fff;font-weight:bold;}
th{background-color:#61B061;color:#fff;}
@media print
{
	#print-preview{border:0;height:100%;box-shadow:none;margin:0;padding:0;}
}
</style>
<div class="purchase-order">
	<h2 style="text-align:center;"><?php _e('Purchase Order', 'mb'); ?></h2>
	<table>
	<tr>
		<td style="width:150px;"><b><?php _e('Date:', 'mb'); ?></b></td>
		<td style="width:40%;"><?php print sb_format_date($purchase->order_date); ?></td>
		<td style="width:40%;text-align:right;"><b><?php _e('Order No.:', 'mb'); ?></b></td>
		<td style="width:250px;"><?php print sb_fill_zeros($purchase->sequence); ?></td>
	</tr>
	<tr>
		<td style="width:150px;"><b><?php _e('User:', 'mb'); ?></b></td>
		<td style="width:40%;"><?php $user = new SB_User($purchase->user_id); print $user->username; ?></td>
		<td style="width:40%;text-align:right;"><b><?php _e('Store:', 'mb'); ?></b></td>
		<td style="width:250px;"><?php print $purchase->store->store_name; ?></td>
	</tr>
	<tr>
		<td style="width:150px;"><b><?php _e('Supplier:', 'mb'); ?></b></td>
		<td style="width:40%;"><?php print $purchase->supplier->supplier_name; ?></td>
		<td style="width:40%;text-align:right;"><b></b></td>
		<td style="width:250px;"></td>
	</tr>
	<tr>
		<td style="width:150px;"><b><?php _e('Notes:', 'mb'); ?></b></td>
		<td colspan="3"><?php print $purchase->details; ?></td>
	</tr>
	</table>
	<h3 style="text-align:center;"><?php _e('Order Items', 'mb'); ?></h3>
	<table style="width:100%;">
	<thead>
	<tr>
		<th class="bg-color col-num"><?php _e('No.', 'mb'); ?></th>
		<th class="bg-color col-code"><?php _e('Code', 'mb'); ?></th>
		<th class="bg-color col-product"><?php _e('Product', 'mb'); ?></th>
		<th class="bg-color col-qty"><?php _e('Qty', 'mb'); ?></th>
		<th class="bg-color col-price"><?php _e('Price', 'mb'); ?></th>
		<th class="bg-color col-total"><?php _e('Total', 'mb'); ?></th>
	</tr>
	</thead>
	<tbody>
	<?php $i = 1; foreach($purchase->GetItems() as $item): ?>
	<tr>
		<td class="col-num"><?php print $i; ?></td>
		<td class="col-code"><?php print $item->product_code; ?></td>
		<td class="col-product"><?php print $item->product_name; ?></td>
		<td class="col-qty"><?php print $item->quantity; ?></td>
		<td class="col-price"><?php print $item->supply_price; ?></td>
		<td class="col-total"><?php print $item->total; ?></td>
	</tr>
	<?php $i++; endforeach; ?>
	</tbody>
	<tfoot>
	<tr>
		<td colspan="3" style=""></td>
		<td colspan="2" class="bg-color total" style=""><?php _e('Total:', 'mb'); ?></td>
		<td class="bg-color total"><?php print $purchase->total; ?></td>
	</tr>
	</tfoot>
	</table>
	<br/><br/><br/><br/><br/>
	<table style="width:100%;">
	<tr>
		<td style="width:50%;text-align:center;font-weight:bold;">
			--------------------------------------------<br/>
			<?php _e('Authorization Signature', 'mb'); ?>
		</td>
		<td style="width:50%;text-align:center;font-weight:bold;">
			--------------------------------------------<br/>
			<?php _e('Supplier Signature', 'mb'); ?>
		</td>
	</tr>
	</table>
</div>
<script>
function mb_print()
{
	this.print({bUI: false, bSilent: true, bShrinkToFit: true});
}
</script>