<?php
/**
 * 
 * @author marcelo
 *
 * @property	int		id
 * @property 	int 	user_id
 * @property 	int		from_store
 * @property	int 	to_store
 * @property	int		sequence
 * @property	string	details
 * @property	string	status
 * @property	int 	receiver_id
 * @property	date	reception_date
 * @property	date	creation_date		
 * @property	SB_MBStore	source_store;
 * @property	SB_MBStore	target_store;
 */
class SB_MBTransfer extends SB_ORMObject
{
	protected $items = array();
	protected $products = array();
	protected	$source_store;
	protected	$target_store;
	
	public function __construct($id = null)
	{
		parent::__construct();
		if( $id )
			$this->GetDbData($id);
	}
	public function GetDbData($id)
	{
		$query = "SELECT * FROM mb_transfers WHERE id = $id LIMIT 1";
		if( !$this->dbh->Query($query) )
			return false;
		$this->_dbData = $this->dbh->FetchRow();
		$this->GetDbItems();
		$this->source_store = new SB_MBStore($this->from_store);
		$this->target_store	= new SB_MBStore($this->to_store);
	}
	public function SetDbData($data)
	{
		$this->_dbData = (object)$data;
	}
	public function GetDbItems()
	{
		$query = "SELECT ti.*, ti.status as item_status, p.* 
					FROM mb_transfer_items ti, mb_products p
					WHERE 1 = 1
					AND ti.product_id = p.product_id
					AND ti.transfer_id = $this->id";
		$this->items = $this->dbh->FetchResults($query);
	}
	public function GetItems()
	{
		if( !count($this->items) )
			$this->GetDbItems();
		
		return $this->items;
	}
	public function AddItem($item)
	{
		$this->items[] = (array)$item;
	}
	/**
	 * Add product to transfer
	 * 
	 * @param SB_MBProduct $product
	 * @param number $quantity
	 */
	public function AddProduct(SB_MBProduct $product, $quantity = 1, $price = null, $batch = null)
	{
		//##Set product transfer data
		$product->transfer_batch	= $batch;
		$product->transfer_qty 		= $quantity;
		$product->transfer_price 	= $price;
		$this->products[] 			= $product;
	}
	/**
	 * Register the transfer
	 * 
	 * @param int $from_store The source store id
	 * @param int $to_store
	 * @param string $from_lot
	 * @param string $to_lot
	 * @param int $user_id
	 * @param string $details
	 * @return int $transfer_id The new transfer id
	 */
	public function DoTransfer($from_store, $to_store, $from_lot, $to_lot, $user_id, $details = '')
	{
		$data = array(
				'user_id'		=> $user_id,
				'from_store'	=> (int)$from_store,
				'to_store'		=> (int)$to_store,
				'from_sequence'	=> self::GetNextFromSequence($from_store),
				'to_sequence'	=> self::GetNextToSequence($to_store),
				'from_lot'		=> $from_lot,
				'to_lot'		=> $to_lot,
				'details'		=> $details,
				'status'		=> 'on_the_way',
				'creation_date'	=> date('Y-m-d H:i:s')
		);
		//##register the transfer
		$transfer_id = $this->dbh->Insert('mb_transfers', $data);
		$transfer_items = array();
		foreach($this->products as $p)
		{
			$transfer_items[] = array(
					'transfer_id'		=> $transfer_id,
					'product_id'		=> $p->product_id,
					'batch'				=> @$p->transfer_batch,
					'quantity'			=> $p->transfer_qty,
					'price'				=> $p->transfer_price ? $p->transfer_price : $p->product_price,
					'creation_date'		=> date('Y-m-d H:i:s')
			);
			//##update product stock into source store
			$this->dbh->Update('mb_products',
					array('product_quantity' 	=> 'OP[product_quantity - '.$p->transfer_qty.']'),
					array('product_id' 			=> $p->product_id));
			//die($this->dbh->lastQuery);
			//##insert kardex
			$this->dbh->Insert('mb_product_kardex', 
					array(
							'product_id' 			=> $p->product_id,
							'in_out'				=> 'output',
							'quantity'				=> $p->transfer_qty,
							'quantity_balance'		=> $p->product_quantity - $p->transfer_qty,
							'unit_price'			=> $p->product_price,
							'total_amount'			=> ($p->product_quantity - $p->transfer_qty) * $p->product_price,
							'monetary_balance'		=> ($p->product_quantity - $p->transfer_qty) * $p->product_cost,
							'transaction_type_id'	=> 0,
							'creation_date'			=> date('Y-m-d H:i:s')
						
					));
			SB_Module::do_action('mb_transfer_update_source_product', $p, $this);
		}
		$this->dbh->InsertBulk('mb_transfer_items', $transfer_items);
		
		return $transfer_id;
	}
	/**
	 * Accept and transfer
	 * 
	 * @param int $receiver_id The user who receive the transfer
	 */
	public function AcceptTransfer($receiver_id)
	{
		//##update the product stock into destination store
		foreach($this->GetItems() as $item)
		{
			if( $item->status == 'complete' ) continue;
			//##check if product exists
			$query = "SELECT * FROM mb_products WHERE product_code = '$item->product_code' AND store_id = $this->to_store LIMIT 1";
			$row	= $this->dbh->FetchRow($query);
			//##check if product exists
			if( !$row )
			{
				$p = new SB_MBProduct($item->product_id);
				//##create the product into destination store
				$data = (array)$p->_dbData;
				$data['user_id'] 				= $this->user_id;
				$data['store_id']				= $this->to_store;
				$data['last_modification_date'] = date('Y-m-d H:i:s');
				$data['creation_date'] 			= date('Y-m-d H:i:s');
				$data['product_quantity']		= $item->quantity;
				//$data['product_price']			= $p->transfer_price;
				unset($data['product_id'], $data['transfer_qty'], $data['transfer_price']);
				$new_id = $this->dbh->Insert('mb_products', $data);
				//##build product meta
				$meta = array();
				foreach($p->meta as $meta_key => $meta_value)
				{
					$meta[] = array(
							'product_id'	=> $new_id,
							'meta_key'		=> $meta_key,
							'meta_value'	=> $meta_value,
							'creation_date'	=> date('Y-m-d H:i:s')
					);
				}
				//##insert product meta
				$this->dbh->InsertBulk('mb_product_meta', $meta);
				SB_Module::do_action('mb_transfer_product_created', $item, $new_id, $p, $this);
				$this->dbh->Update('mb_transfer_items', array('status' => 'complete'), array('id' => $item->id));
			}
			else
			{
				//##increment the quantity into destination store
				$this->dbh->Update('mb_products',
						array(
								'product_quantity' 	=> 'OP[product_quantity + '.$item->quantity.']',
								/*
								'product_price'		=> $p->product_price,
								'product_price_2'	=> $p->product_price_2,
								'product_price_3'	=> $p->product_price_3,
								'product_price_4'	=> $p->product_price_4
								*/
						),
						array('product_id' => $row->product_id));
				SB_Module::do_action('mb_transfer_product_updated', $row->product_id, $item, $this);
				
				$this->dbh->Update('mb_transfer_items', array('status' => 'complete'), array('id' => $item->id));
			}
		}
		//##update the transfer status
		$this->dbh->Update('mb_transfers', 
				array('status' => 'complete', 'receiver_id' => $receiver_id, 'reception_date' => date('Y-m-d H:i:s')), 
				array('id' => $this->id));
		SB_Module::do_action('mb_transfer_complete', $this);
	}
	public function Revert()
	{
		if( $this->status != 'complete' )
		{
			return false;
		}
		$res = true;
		foreach($this->items as $item)
		{
			$prod = new SB_MBProduct($item->product_id);
			//##update source store
			$this->dbh->Update('mb_products', 
					array('product_quantity' => "OP[product_quantity + $item->quantity]"), 
					array('product_id' => $item->product_id));
			//##update distination store
			$d_product = $this->dbh->FetchRow("SELECT * FROM mb_products WHERE product_code = '$prod->product_code' AND store_id = $this->to_store LIMIT 1");
			if( $d_product )
			{
				$this->dbh->Update('mb_products',
						array('product_quantity' => "OP[product_quantity - $item->quantity]"),
						array('product_id' => $d_product->product_id));
			} 
			SB_Module::do_action('mb_transfer_revert_item', $item, $d_product);
			$this->dbh->Update('mb_transfer_items', array('status' => 'reverted'), array('id' => $item->id));
		}
		$this->dbh->Update('mb_transfers', array('status' => 'reverted'), array('id' => $this->id));
		return $res;
	}
	public static function GetNextFromSequence($store_id)
	{
		$query = "SELECT MAX(from_sequence) FROM mb_transfers WHERE from_store = $store_id";
		$seq = (int)SB_Factory::getDbh()->GetVar($query);
		if( !$seq )
			$seq = 1;
		else
			$seq++;
		
		return $seq;
	}
	public static function GetNextToSequence($store_id)
	{
		$query = "SELECT MAX(to_sequence) FROM mb_transfers WHERE to_store = $store_id";
		$seq = (int)SB_Factory::getDbh()->GetVar($query);
		if( !$seq )
			$seq = 1;
		else
			$seq++;
	
		return $seq;
	}
}