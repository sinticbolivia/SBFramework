<?php
/**
 * 
 * @author marcelo
 * @property int category_id
 * @property string name
 * @property int store_id
 */
class SB_MBCategory extends SB_ORMObject
{
	protected $_products = array();
	
	public function __construct($category_id = null)
	{
		if( $category_id )
			$this->GetDbData($category_id);
	}
	public function GetDbData($id)
	{
		$dbh = SB_Factory::getDbh();
		$query = "SELECT * FROM mb_categories WHERE category_id = $id";
		if( !$dbh->Query($query) )
			return false;
		$this->_dbData = $dbh->FetchRow();
	}
	public function SetDbData($data)
	{
		$this->_dbData = $data;
	}
	public function getProducts()
	{
		if( count($this->_products) <= 0)
		{
			$prods = array();
			$i = 0;
			foreach($prods as $p)
			{
				$this->_products[$i] = new SB_MBProduct();
				$this->_products[$i]->SetDbData($p);
				$i++; 
			}
		}
		return $this->_products;
	}
	public function jsonSerialize()
	{
		return $this->_dbData;
	}
}