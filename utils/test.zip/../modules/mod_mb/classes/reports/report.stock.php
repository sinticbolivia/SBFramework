<?php
class SB_MBReportStock extends SB_ORMObject
{
	public		$key = 'stock';
	public		$tabLabel;
	public 		$tabLink;
	
	public function __construct()
	{
		parent::__construct();
		$this->tabLabel	= __('Inventory', 'mb');
		$this->tabLink	= SB_Route::_('index.php?mod=mb&view=reports.default&report=stock');
	}
	public function GetDbData($id){}
	public function SetDbData($data){}
	public function GetTabs()
	{
		?>
		<div class="navbar navbar-default">
			<ul class="nav navbar-nav">
				<li class="<?php print !SB_Request::getString('tab') ? 'active' : ''; ?>">
					<a href="<?php print $this->tabLink; ?>"><?php print $this->tabLabel; ?></a></li>
				<?php SB_Module::do_action('mb_report_stock_tabs'); ?>
			</ul>
		</div>
		<?php 
	}
	public function Form()
	{
		$user		= sb_get_current_user();
		$tab 		= SB_Request::getString('tab', 'default');
		$tab		= strtolower(preg_replace('/[^a-zA-Z0-9]/', '', $tab));
		$this->GetTabs();
		$form_method 	= 'Form'. ucfirst($tab);
		if( method_exists($this, $form_method) )
		{
			call_user_func(array($this, $form_method));
		}
		SB_Module::do_action('mb_report_stock_form_'.$tab);
	}
	public function FormDefault()
	{
		$user		= sb_get_current_user();
		$store_id 	= SB_Request::getInt('store_id');
		$valued		= SB_Request::getInt('valued');
		?>
		<form action="index.php" method="get" class="hidden-print">
			<input type="hidden" name="mod" value="mb" />
			<input type="hidden" name="view" value="reports.default" />
			<input type="hidden" name="report" value="stock" />
			<input type="hidden" name="build" value="1" />
			<div class="row">
				<div class="col-md-3">
					<div class="form-group">
						<label><?php _e('Store', 'mb'); ?></label>
						<select name="store_id" class="form-control">
							<option><?php _e('-- store --', 'mb'); ?></option>
							<?php foreach(SB_Warehouse::GetUserStores($user) as $store): ?>
							<option value="<?php print $store->store_id; ?>" <?php print $store_id == $store->store_id ? 'selected' : ''; ?>>
								<?php print $store->store_name; ?>
							</option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
				<div class="col-md-1">
					<div class="form-group">
						<label>&nbsp;</label><br/>
						<button type="submit" class="btn btn-primary"><?php _e('Build', 'mb'); ?></button>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-2">
					<div class="form-group">
						<label>
							<input type="checkbox" name="valued" value="1" <?php print $valued ? 'checked' : ''; ?> />
							<?php _e('Valued Report', 'mb'); ?>
						</label>
					</div>
				</div>
				<?php SB_Module::do_action('mb_report_stock_options'); ?>
			</div>
		</form>
		<?php 
	}
	public function Build()
	{
		$tab = SB_Request::getString('tab', 'default');
		$build_method 	= 'Build'.ucfirst($tab);
		if( method_exists($this, $build_method) )
			call_user_func(array($this, 'Build'.ucfirst($tab)));
		SB_Module::do_action('mb_report_sales_build_'.$tab);
		
	}
	public function BuildDefault()
	{
		$build = SB_Request::getInt('build');
		if( !$build )
			return;
		$store_id	= SB_Request::getInt('store_id');
		$valued		= SB_Request::getInt('valued');
		$store		= null;
		$products 	= array();
		if( !$store_id )
		{
			$title 			= $valued ? __('Global Valued Stock Report', 'mb') : __('Global Stock Report', 'mb');
			$query = "SELECT product_code, 
							product_name, 
							pm.meta_value presentacion,
							pc.meta_value concentracion,
							SUM(product_quantity) product_quantity, 
							product_cost, 
							SUM(product_quantity) * product_cost
							
						FROM mb_products p, mb_product_meta pm,mb_product_meta pc
						WHERE 1 = 1
						AND pm.product_id = p.product_id
						and pc.product_id = p.product_id
						AND pm.meta_key = '_presentacion'
						and pc.meta_key = '_concentracion'
						GROUP BY product_code
						ORDER BY product_name ASC";
			
			$products		= $this->dbh->FetchResults($query);
		}
		else 
		{
			$store 			= new SB_MBStore($store_id);
			$title 			= $valued ? sprintf(__('Valued Stock Report - %s', 'mb'), $store->store_name) : sprintf(__('Stock Report - %s', 'mb'), $store->store_name);
			$products		= SB_Warehouse::getStoreProducts($store_id, -1, -1);
		}
		
		$total_qty 		= 0;
		$total_items 	= 0;
		$total_cost		= 0;
		?>
		<p class="hidden-print">
			<a href="javascript:;" onclick="print();" class="btn btn-warning">
				<span class="glyphicon glyphicon-print"></span> <?php print _e('Print', 'mb'); ?>
			</a>
		</p>
		<h2 class="text-center"><?php print $title; ?></h2>
		<table class="table table-condensed table-bordered">
		<thead>
		<tr>
			<th class="text-center"><?php _e('No.', 'mb'); ?></th>
			<th class="text-center"><?php _e('Code', 'mb'); ?></th>
			<th class="text-center"><?php _e('Product', 'mb'); ?></th>
			<?php if( isset($products[0]->presentacion) ): ?>
			<th class="text-center"><?php _e('Presentacion', 'mb'); ?></th>
			<?php endif; ?>
			<?php if( isset($products[0]->concentracion) ): ?>
			<th class="text-center"><?php _e('Concentracion', 'mb'); ?></th>
			<?php endif; ?>
			<th class="text-center"><?php _e('Qty', 'mb'); ?></th>
			<?php if( $valued ): ?>
			<th class="text-center"><?php _e('Cost', 'mb'); ?></th>
			<th class="text-center"><?php _e('Total', 'mb'); ?></th>
			<?php endif; ?>
		</tr>
		</thead>
		<tbody>
		<?php $i = 1; foreach($products as $p): ?>
		<?php
		$total_cost += $p->product_cost * $p->product_quantity; 
		?>
		<tr>
			<td class="text-center"><?php print $i; ?></td>
			<td><?php print $p->product_code; ?></td>
			<td>
				<?php 
				print str_replace(array(@$p->presentacion, @$p->concentracion, '()', ''), '', $p->product_name); 
				?>
			</td>
			<?php if( isset($p->presentacion) ): ?>
			<td class="text-center"><?php print $p->presentacion ?></td>
			<?php endif; ?>
			<?php if( isset($p->concentracion) ): ?>
			<td class="text-center"><?php print $p->concentracion; ?></td>
			<?php endif; ?>
			<td class="text-right"><?php print $p->product_quantity; ?></td>
			<?php if( $valued ): ?>
			<td class="text-right"><?php print number_format($p->product_cost, 2, '.', ','); ?></td>
			<td class="text-right"><?php print number_format($p->product_cost * $p->product_quantity, 2, '.', ','); ?></td>
			<?php endif; ?>
		</tr>
		<?php $i++; endforeach; ?>
		</tbody>
		<?php if( $valued ): ?>
		<tfoot>
		<tr>
			<td colspan="<?php print $valued ? 5 : 3; ?>" style="text-align:right;font-weight:bold;font-size:20px;"><?php _e('Total', 'mb'); ?></td>
			<td style="text-align:right;">
				<span style="font-weight:bold;font-size:20px;" class="label label-success"><?php print number_format($total_cost, 2, '.', ','); ?></span>
			</td>
		</tr>
		</tfoot>
		<?php endif; ?>
		</table>
		<?php 
	}
}