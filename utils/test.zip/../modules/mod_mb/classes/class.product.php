<?php
/**
 * 
 * @author marcelo
 * @property int product_id
 * @property string		product_code
 * @property string product_name
 * @property int store_id
 * @property int product_quantity
 * @property float product_price
 * @property float product_price_2
 * @property float product_price_3
 * @property float product_price_4
 */
class SB_MBProduct extends SB_ORMObject
{
    protected $_store = null;
    protected $_images = array();
    protected $_categories = array();
    public $categories_ids = array();
    public $kardex = array();
    
	public function __construct($product_id = null)
	{
		parent::__construct();
		if( $product_id )
		    $this->GetDbData($product_id);
	}
	public function GetDbData($product_id)
	{
		$query = "SELECT * FROM mb_products WHERE product_id = $product_id LIMIT 1";
		$dbh = SB_Factory::getDbh();
		if( !$dbh->Query($query) )
			return false;
		$this->_dbData = $dbh->FetchRow();
		$this->GetDbMeta();
		//get categories
		$this->GetDbCategories();
		//##get store
		$this->_store = new SB_MBStore($this->store_id);
		$this->getImages();
		/*
		//get product kardex
		//$query = "SELECT k.*, tt.transaction_key, tt.transaction_name, tt.transaction_description, tt.in_out 
		$query = "SELECT k.*, tt.transaction_key, tt.transaction_name, tt.transaction_description
					FROM product_kardex k 
					LEFT JOIN transaction_types tt ON k.transaction_type_id = tt.transaction_type_id 
					WHERE product_code = '$this->product_code' 
					ORDER BY creation_date DESC";
		
		$res = $dbh->Query($query);
		$this->kardex = $dbh->FetchResults();
		//print_r($this->kardex);
		*/
	}
	public function SetDbData($data)
	{
		$this->_dbData = $data;
		if( $this->store_id )
		{
		    $this->_store = new SB_MBStore($this->store_id);
		}
		$this->getImages();
		$this->GetDbCategories();
	}
	public function GetDbMeta()
	{
		$query = "SELECT * FROM mb_product_meta WHERE product_id = $this->product_id";
		foreach($this->dbh->FetchResults($query) as $row)
		{
			$this->meta[$row->meta_key] = trim($row->meta_value);
		}
	}
	public function GetDbCategories()
	{
		$query = "SELECT c.* FROM mb_product2category p2c, mb_categories c WHERE c.category_id = p2c.category_id AND product_id = $this->product_id";
		$res = $this->dbh->Query($query);
		if($res)
		{
			foreach($this->dbh->FetchResults() as $r)
			{
				$this->_categories[] = $r;
				$this->categories_ids[] = $r->category_id;
			}
		}
	}
	public function getImages()
	{
	    if( empty($this->_images) )
	    {
	    	$query = "SELECT * FROM attachments WHERE object_type = 'product' AND object_id = $this->product_id AND type = 'image'";
	    	$this->_images = $this->dbh->FetchResults($query);
	    }
		
	    return $this->_images;
	}
	public function getStore()
	{
		return $this->_store;
	}
	public function getFeaturedImage()
	{
		$this->getImages();
		//print_r($this->_images);die();
		if( !isset($this->meta['_featured_image']) )
		{
			if( !count($this->_images) )
			{
				return BASEURL . '/images/no-image.png';
			}
			else 
			{
				return file_exists(UPLOADS_DIR . '/products/' . $this->_images[0]->file) ? UPLOADS_URL . '/products/' . $this->_images[0]->file :
							BASEURL . '/images/no-image.png';
			}
		}
		$id = (int)$this->meta['_featured_image'];
		$file = null;
		foreach($this->_images as $img)
		{
			if( $img->attachment_id == $id )
			{
				$file = $img->file;
				break;
			}
		}
		return UPLOADS_URL . '/products/' . $file;
	}
	public function GetAsmComponents()
	{
		$query = "SELECT p.product_id, p.product_code, p.product_name, a2p.qty_required 
					FROM mb_assemblie2product a2p, mb_products p 
					WHERE 1 = 1
					AND a2p.product_id = p.product_id
					AND a2p.assembly_id = $this->product_id";
		return $this->dbh->FetchResults($query);
	}
	public function __get($var)
	{
		if( $var == 'price' )
		{
			return sprintf("%.2f", number_format($this->product_price, 2));
		}
		/*
		if( $var == 'product_name' )
		{
			return html_entity_decode($this->_dbData->product_name);
		}
		*/
		if( $var == 'excerpt' )
		{
			$desc = trim(strip_tags($this->product_description));
			return empty($desc) ? __('There is no description', 'mb') : substr($desc, 0, 128) . '...';
		}
		return parent::__get($var);
	}
	public function GetCategoriesName()
	{
		$cats = array();
		foreach($this->_categories as $c)
		{
			$cats[] = $c->name;
		}
		return implode(',', $cats);
	}
}