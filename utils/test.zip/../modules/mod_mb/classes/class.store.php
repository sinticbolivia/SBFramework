<?php
class SB_MBStore extends SB_ORMObject
{
	protected $_products = array();
	
	public function __construct($store_id = null)
	{
		parent::__construct();
		if($store_id)
			$this->getDbData($store_id);
	}
	public function GetDbData($store_id = null)
	{
		$dbh = SB_Factory::getDbh();
		$query = "SELECT * FROM mb_stores WHERE store_id = $store_id";
		if( !$dbh->Query($query) )
			return false;
		$this->_dbData = $dbh->FetchRow();
		$this->GetDbMeta();
	}
	public function SetDbData($data)
	{
		$this->_dbData = $data;
	}
	public function GetDbMeta()
	{
		$query = "SELECT * FROM mb_store_meta WHERE store_id = $this->store_id";
		foreach($this->dbh->FetchResults($query) as $row)
		{
			$this->meta[$row->meta_key] = $row->meta_value;
		}
	}
	public function getProducts()
	{
		if( empty($this->_products) )
		{
			$this->_products = SB_Warehouse::getStoreProducts($this->store_id);
		}
		return $this->_products;
	}
}