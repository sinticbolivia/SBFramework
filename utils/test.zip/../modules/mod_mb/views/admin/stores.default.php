<?php
?>
<div class="wrap">
	<h2 id="page-title"><?php print SBText::_('Stores', 'mb'); ?></h2>
	<div>
		<a href="<?php print SB_Route::_('index.php?mod=mb&view=stores.new'); ?>" class="btn btn-primary">
			<?php print SB_Text::_('New Store', 'mb'); ?>
		</a>
		<a href="<?php print SB_Route::_('index.php?mod=mb&view=warehouse.new'); ?>" class="btn btn-info">
			<?php print SB_Text::_('New Warehouse', 'mb'); ?>
		</a>
		<a href="<?php print SB_Route::_('index.php?mod=mb&view=batch.new'); ?>" class="btn btn-warning">
			<?php print SB_Text::_('New Batch', 'mb'); ?>
		</a>
	</div><br/>
	<table id="stores-datagrid" class="table">
	<thead>
	<tr>
		<th>#</th>
		<th><?php print SB_Text::_('Name', 'mb'); ?></th>
		<th><?php print SB_Text::_('Address', 'mb'); ?></th>
		<th><?php print SB_Text::_('Total Products', 'mb'); ?></th>
		<th><?php print SB_Text::_('Actions', 'mb'); ?></th>
	</tr>
	</thead>
	<tbody>
	<?php if(count($stores)): $i = 1;foreach($stores as $store): ?>
	<tr>
		<td><?php print $i; ?></td>
		<td><?php print $store->store_name; ?></td>
		<td><?php print $store->store_address; ?></td>
		<td>
			<?php print count($store->getProducts());?>
		</td>
		<td>
			<div class="btn-group">
				<button data-toggle="dropdown" class="btn btn-small btn-default dropdown-toggle">
					<?php print SB_Text::_('Action', 'mb')?><span class="caret"></span>
				</button>
				<ul class="dropdown-menu align-left" role="menu">
					<li>
						<a href="<?php print SB_Route::_('index.php?mod=mb&view=stores.edit&id='.$store->store_id)?>">
							<?php print SB_Text::_('Edit', 'mb')?></a></li>
					<li>
						<a href="<?php print SB_Route::_('index.php?mod=mb&task=stores.delete&id='.$store->store_id)?>" class="confirm"
							data-message="<?php print SBText::_('Are you sure to delete the store?'); ?>">
							<?php print SB_Text::_('Delete', 'mb')?></a></li>
				</ul>
			</div>
		</td>
	</tr>
	<?php $i++; endforeach; else: ?>
	<tr><td colspan="4"><?php print SB_Text::_('No stores found', 'mb'); ?></td></tr>
	<?php endif; ?>
	</tbody>
	</table>
</div>