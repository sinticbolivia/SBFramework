<?php
?>
	<div id="products" class="list-layout">
		<div id="products-table" class="pos-table">
			<div class="table-header">
				<div class="trow">
					<div class="col column-image"><?php print SBText::_('Image', 'mb'); ?></div>
					<div class="col column-id"><?php print SBText::_('ID', 'mb'); ?></div>
					<div class="col column-product"><?php print SBText::_('Product', 'mb'); ?></div>
					<div class="col column-qty"><?php print SBText::_('Qty', 'mb'); ?></div>
					<div class="col column-price"><?php print SBText::_('Price', 'mb'); ?></div>
					<div class="col column-add">&nbsp;<?php  ?></div>
				</div>
			</div>
			<div class="table-body">
				<?php if( isset($products) ): $i = 1; foreach($products as $p): ?>
				<?php include 'product_row.php'; ?>
				<?php $i++; endforeach; endif;?>
			</div>
		</div><!-- end class="pos-table" -->
	</div><!-- end id="products" -->
