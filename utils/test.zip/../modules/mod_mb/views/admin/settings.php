<?php
?>
<div class="wrap">
	<form action="" method="post" enctype="multipart/form-data">
		<input type="hidden" name="mod" value="mb" />
		<input type="hidden" name="task" value="save_settings" />
		<h2>
			<span class="glyphicon glyphicon-wrench"></span>
			<?php _e('Mono Business Settings', 'mb'); ?>
			<div class="pull-right">
				<button type="submit" class="btn btn-success"><?php _e('Save', 'mb'); ?></button>
			</div>
		</h2>
		<ul class="nav nav-tabs">
			<li class="active"><a href="#mono-business" data-toggle="tab"><?php _e('General', 'mb'); ?></a></li>
			<li><a href="#barcode" data-toggle="tab"><?php _e('Barcode', 'mb'); ?></a></li>
			<?php SB_Module::do_action('mb_settings_tab', $ops); ?>
		</ul>
		<div class="tab-content">
			<div id="mono-business" class="tab-pane active">
				<div class="form-group">
					<?php if( @$ops->business_logo ): ?>
					<div class="text-center">
						<img src="<?php print UPLOADS_URL; ?>/<?php print $ops->business_logo; ?>" alt="" />
					</div>
					<?php endif; ?>
					<label><?php print SBText::_('Business Logo:', 'mb'); ?></label>
					<input type="file" name="business_logo" value="" class="form-control" />
				</div>
				<div class="form-group">
					<label><?php print SBText::_('Business Name:', 'mb'); ?></label>
					<input type="text" name="ops[business_name]" value="<?php print @$ops->business_name; ?>" class="form-control" />
				</div>
				<div class="form-group">
					<label><?php print SBText::_('Business Address:', 'mb'); ?></label>
					<input type="text" name="ops[business_address]" value="<?php print @$ops->business_address; ?>" class="form-control" />
				</div>
				<div class="form-group">
					<label><?php print SBText::_('Business Telephone:', 'mb'); ?></label>
					<input type="text" name="ops[business_phone]" value="<?php print @$ops->business_phone; ?>" class="form-control" />
				</div>
				<div class="form-group">
					<label><?php print SBText::_('Business Mobile Telephone:', 'invoices'); ?></label>
					<input type="text" name="ops[business_mobile_telephone]" value="<?php print @$ops->business_mobile_telephone; ?>" class="form-control" />
				</div>
				<div class="form-group">
					<label><?php print SBText::_('City:', 'invoices'); ?></label>
					<input type="text" name="ops[business_city]" value="<?php print @$ops->business_city; ?>" class="form-control" />
				</div>
				<div class="form-group">
					<label><?php print SBText::_('Country:', 'invoices'); ?></label>
					<select name="ops[business_country]" class="form-control">
						<option value="-1"><?php print SBText::_('-- country --', 'invoices'); ?></option>
						<?php foreach( include INCLUDE_DIR . SB_DS . 'countries.php' as $code => $country): ?>
						<option value="<?php print $code; ?>" <?php print @$ops->business_country == $code ? 'selected' : ''; ?>><?php print $country; ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<div id="barcode" class="tab-pane">
				<h3><?php _e('Barcode Generation', 'mb'); ?></h3>
				<div class="form-group">
					<label><?php _e('Country Code'); ?></label>
					<input type="text" name="ops[barcode_ean13_country]" value="<?php print @$ops->barcode_ean13_country; ?>" min="0" maxlength="3" class="form-control" />
				</div>
				<div class="form-group">
					<label><?php _e('Company Code'); ?></label>
					<input type="text" name="ops[barcode_ean13_company]" value="<?php print @$ops->barcode_ean13_company; ?>" min="0" maxlength="5" class="form-control" />
				</div>
			</div><!-- end id="barcode" -->
			<?php SB_Module::do_action('mb_settings_pane', $ops); ?>
		</div>
	</form>
</div>