<?php
$stores = SB_Warehouse::getStores();
?>
<div class="wrap">
	<h2><?php _e('Import Products', 'mb'); ?></h2>
	<form action="" method="post" enctype="multipart/form-data">
		<input type="hidden" name="mod" value="mb" />
		<input type="hidden" name="task" value="do_import" />
		<div class="row">
			<div class="col-md-4">
				<div class="form-group">
					<label><?php _e('Store', 'mb')?></label>
					<select id="store_id" name="store_id" class="form-control">
						<option value="-1"><?php _e('-- store --', 'mb'); ?></option>
						<?php foreach($stores as $s): ?>
						<option value="<?php print $s->store_id; ?>"><?php print $s->store_name; ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<div class="col-md-4">
				<div class="form-group">
					<label><?php _e('Category', 'mb'); ?></label>
					<select id="category_id" name="category_id" class="form-control">
						<option value="-1"><?php _e('-- category --', 'mb'); ?></option>
					</select>
				</div>
			</div>
			<div class="col-md-4">
				
			</div>
		</div>
		<div class="row">
			<div class="col-xs-12 col-md-4">
				<div class="form-group">
					<label><?php _e('File:', 'mb');?></label>
					<input type="file" name="the_file" value="" class="form-control" />
				</div>
			</div>
			<div class="col-xs-12 col-md-4">
				<div class="form-group">
					<label><?php print SBText::_('Separator:', 'mb');?></label>
					<input type="text" name="separator" value=","  class="form-control" />
				</div>	
			</div>
			<div class="col-xs-12 col-md-4">
				<div class="form-group">
					<label><?php _e('File Type', 'mb'); ?></label>
					<select name="file_type" class="form-control">
						<option value="-1"><?php _e('-- file type --', 'mb'); ?></option>
						<option value="xls_file"><?php _e('Excel File', 'mb'); ?></option>
						<option value="csv_file"><?php _e('CSV File', 'mb'); ?></option>
						
						<option value="monobusiness_file"><?php _e('Mono Business (SQLite)', 'mb'); ?></option>
						<option value="monobusiness_csv"><?php _e('Mono Business (CSV)', 'mb'); ?></option>
						<option value="epos_file"><?php _e('EPoint of Sale (SQLite)', 'mb'); ?></option>
						<option value="epos_file"><?php _e('EPoint of Sale (CSV)', 'mb'); ?></option>
						
					</select>
				</div>
			</div>
		</div>
		<fieldset>
			<fieldset><a data-toggle="collapse" href="#adv-options" class="btn btn-default"><?php _e('Advanced Options', 'mb'); ?> <span class="caret"></span></a></fieldset>
			<div id="adv-options" class="collapse">
				<div class="row">
					<div class="col-xs-12 col-md-3">
						<div class="form-group">
							<label><?php _e('Excel Sheet', 'mb'); ?></label>
							<input type="number" name="sheet_num" value="0" class="form-control" />
						</div>
					</div>
					<div class="col-xs-12 col-md-3">
						<div class="form-group">
							<label><?php _e('Row Start:', 'mb'); ?></label>
							<input type="number" name="row_start" min="1" value="1" class="form-control" />
						</div>
					</div>
					<div class="col-xs-12 col-md-3">
						<div class="form-group">
							<label><?php _e('Code Column:', 'mb'); ?></label>
							<select id="" name="code_column" class="form-control">
								<?php foreach(array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z') as $i => $l): ?>
								<option value="<?php print $i; ?>"><?php print $l; ?></option>
								<?php endforeach;?>
							</select>
						</div>
					</div>
					<div class="col-xs-12 col-md-3">
						<div class="form-group">
							<label><?php _e('Name Column:', 'mb'); ?></label>
							<select id="" name="name_column" class="form-control">
								<?php foreach(array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z') as $i => $l): ?>
								<option value="<?php print $i; ?>"><?php print $l; ?></option>
								<?php endforeach;?>
							</select>
						</div>
					</div>
					<div class="col-xs-12 col-md-3">
						<div class="form-group">
							<label><?php _e('Qty Column:', 'mb'); ?></label>
							<select id="" name="qty_column" class="form-control">
								<?php foreach(array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z') as $i => $l): ?>
								<option value="<?php print $i; ?>"><?php print $l; ?></option>
								<?php endforeach;?>
							</select>
						</div>
					</div>
					<div class="col-xs-12 col-md-3">
						<div class="form-group">
							<label><?php _e('Cost Column:', 'mb'); ?></label>
							<select id="" name="cost_column" class="form-control">
								<?php foreach(array('-1' => '-- cost --', 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z') as $i => $l): ?>
								<option value="<?php print $i; ?>"><?php print $l; ?></option>
								<?php endforeach;?>
							</select>
						</div>
					</div>
					<div class="col-xs-12 col-md-3">
						<div class="form-group">
							<label><?php _e('Price Column:', 'mb'); ?></label>
							<select id="" name="price_column" class="form-control">
								<?php foreach(array('-1' => '-- price --', 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z') as $i => $l): ?>
								<option value="<?php print $i; ?>"><?php print $l; ?></option>
								<?php endforeach;?>
							</select>
						</div>
					</div>
					<div class="col-xs-12 col-md-3">
						<div class="form-group">
							<label><?php _e('Price 2 Column:', 'mb'); ?></label>
							<select id="" name="price_column_2" class="form-control">
								<?php foreach(array('-1' => '-- price --', 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z') as $i => $l): ?>
								<option value="<?php print $i; ?>"><?php print $l; ?></option>
								<?php endforeach;?>
							</select>
						</div>
					</div>
					<div class="col-xs-12 col-md-3">
						<div class="form-group">
							<label><?php _e('Price 3 Column:', 'mb'); ?></label>
							<select id="" name="price_column_3" class="form-control">
								<?php foreach(array('-1' => '-- price --', 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z') as $i => $l): ?>
								<option value="<?php print $i; ?>"><?php print $l; ?></option>
								<?php endforeach;?>
							</select>
						</div>
					</div>
					<div class="col-xs-12 col-md-3">
						<div class="form-group">
							<label><?php _e('Price 4 Column:', 'mb'); ?></label>
							<select id="" name="price_column_4" class="form-control">
								<?php foreach(array('-1' => '-- price --', 'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z') as $i => $l): ?>
								<option value="<?php print $i; ?>"><?php print $l; ?></option>
								<?php endforeach;?>
							</select>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="form-group">
						<label class="">
							<?php _e('Update just prices', 'mb'); ?>
							<input type="checkbox" name="update_prices_only" value="1" />
						</label>
					</div>
				</div>
			</div>
		</fieldset><br/>
		<div class="form-group">
			<a href="<?php print SB_Route::_('index.php?mod=mb'); ?>" class="btn btn-danger"><?php _e('Cancel', 'mb'); ?></a>
			<button type="submit" class="btn btn-secondary"><?php _e('Import Now', 'mb'); ?></button>
		</div>
	</form>
</div>
<script>
jQuery(function()
{
	jQuery('#store_id').change(function()
	{
		if( this.value <= 0 )
			return false;
		jQuery('#category_id').html('<option value="-1"><?php _e('-- category --', 'mb'); ?></option>');
		jQuery.get('index.php?mod=mb&task=ajax&action=get_store_cats&store_id='+this.value, function(res)
		{
			if(res.status == 'ok')
			{
				jQuery.each(res.categories, function(i, cat)
				{
					var op = jQuery('<option value="'+cat.category_id+'">'+cat.name+'</option>');
					jQuery('#category_id').append(op);
				});
			}
			else
			{
				alert(res.error);
			}
		});
	});
});
</script>
