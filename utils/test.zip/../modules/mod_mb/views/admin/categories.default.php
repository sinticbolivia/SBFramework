<?php

?>
<div class="wrap">
	<h2 id="page-title">
		<?php print SBText::_('Categories', 'mb'); ?>
		<a class="btn btn-primary pull-right" href="<?php print SB_Route::_('index.php?mod=mb&view=categories.new')?>">
			<?php print SB_Text::_('Create new category', 'mb'); ?>
		</a>
	</h2>
	<form id="" class="form-search form-inline" action="" method="get">
		<input type="hidden" name="mod" value="mb" />
		<input type="hidden" name="view" value="categories.default" />
		<div class="form-group">
			<input type="text" name="keyword" value="<?php print SB_Request::getString('keyword'); ?>" class="form-control" placeholder="<?php print SBText::_('Search...', 'mb'); ?>" />
			<select name="search_by" class="form-control">
				<option value="name"><?php print SB_Text::_('Name', 'mb'); ?></option>
				<option value="identifier"><?php print SB_Text::_('Identifier', 'mb'); ?></option>
			</select>
			<button type="submit" class="btn btn-default"><?php print SB_Text::_('Search', 'mb')?></button>
		</div>
	</form><br/>
	<table class="table">
	<thead>
	<tr>
		<th>#</th>
		<th><?php print SB_Text::_('Name', 'mb'); ?></th>
		<th><?php print SB_Text::_('Description', 'mb'); ?></th>
		<th><?php print SB_Text::_('Store', 'mb'); ?></th>
		<th><?php print SB_Text::_('Actions', 'mb'); ?></th>
	</tr>
	</thead>
	<tbody>
	<?php if( count($categories) ): $i = 1; foreach($categories as $cat): ?>
	<tr>
		<td><?php print $i; ?></td>
		<td><?php print $cat->name; ?></td>
		<td><?php print $cat->description; ?></td>
		<td><?php print $cat->store_name; ?></td>
		<td>
			<div class="btn-group">
				<button data-toggle="dropdown" class="btn btn-default btn-small dropdown-toggle">
					<i class="icon-tasks"></i>&nbsp;<?php print SB_Text::_('Action', 'mb_w')?> <span class="caret"></span>
				</button>
				<ul class="dropdown-menu" role="menu">
					<li>
						<a href="<?php print SB_Route::_('index.php?mod=mb&view=categories.edit&id='.$cat->category_id)?>">
							<i class="icon-edit"></i>&nbsp;<?php print SB_Text::_('Edit', 'mb_w')?>
						</a>
					</li>
					<li>
						<a class="confirm" href="<?php print SB_Route::_('index.php?mod=mb&task=categories.delete&id='.$cat->category_id)?>"
							data-message="<?php print SBText::_('Are you sure to delete the category?', 'mb'); ?>">
							<i class="icon-remove"></i>&nbsp;<?php print SB_Text::_('Delete', 'mb_w')?>
						</a>
					</li>
				</ul>
			</div>
		</td>
	</tr>
		<?php if(isset($cat->childs)): foreach($cat->childs as $c): $i++; ?>
			<tr>
				<td><?php print $i; ?></td>
				<td><?php printf("&nbsp;&nbsp;&nbsp;- %s", $c->name); ?></td>
				<td><?php print $c->description; ?></td>
				<td>
					<div class="btn-group">
						<button data-toggle="dropdown" class="btn btn-small dropdown-toggle">
							<i class="icon-tasks"></i><?php print SB_Text::_('Action', 'mb_w')?> <span class="caret"></span></button>
						<ul class="dropdown-menu" role="menu">
							<li>
								<a href="<?php print SB_Route::_('index.php?mod=warehouse&task=category.edit_category&id='.$c->category_id)?>">
									<i class="icon-edit"></i>&nbsp;<?php print SB_Text::_('Edit', 'mb_w')?>
								</a>
							</li>
							<li>
								<a class="confirm" href="<?php print SB_Route::_('index.php?mod=warehouse&task=category.delete_category&id='.$c->category_id)?>">
									<i class="icon-remove"></i>&nbsp;<?php print SB_Text::_('Delete', 'mb_w')?>
								</a>
							</li>
						</ul>
					</div>
				</td>
			</tr>
		<?php endforeach; endif;?>
	<?php $i++; endforeach; else: ?>
	<tr><td colspan="4"><?php print SB_Text::_('There are no categories yet.')?></td></tr>
	<?php endif; ?>
	</tbody>
	</table>
</div>