<?php

?>
<div class="wrap">
	<form action="" method="post" id="form-quote" class="form-group-sm" >
		<input type="hidden" name="mod" value="mb" />
		<input type="hidden" name="task" value="purchases.save" />
		<?php if( isset($purchase) ): ?>
		<input type="hidden" name="purchase_id" value="<?php print $purchase->order_id; ?>" />
		<?php endif; ?>
		<h2>
			<?php print $title; ?>
			<span class="pull-right">
				<a href="<?php print SB_Route::_('index.php?mod=mb&view=purchases.default'); ?>" class="btn btn-danger">
					<span class="glyphicon glyphicon-remove"></span> <?php _e('Cancel', 'mb'); ?>
				</a>
				<?php if( isset($purchase) ): ?>
				<a href="<?php print SB_Route::_('index.php?mod=mb&view=purchases.print&id='.$purchase->order_id); ?>" class="btn btn-warning" 
					target="_blank">
					<span class="glyphicon glyphicon-print"></span> <?php _e('Print', 'mb'); ?>
				</a>
				<?php if( $purchase->status != 'complete' ): ?>
				<a href="<?php print SB_Route::_('index.php?mod=mb&task=purchases.receive&id='.$purchase->order_id)?>" class="btn btn-primary">
					<span class="glyphicon glyphicon-cog"></span> <?php _e('Receive Stock', 'mb'); ?>
				</a>
				<?php endif; ?>
				<?php endif; ?>
				<?php if( (isset($purchase) && $purchase->status != 'complete') || !isset($purchase) ): ?>
				<button type="submit" class="btn btn-success">
					<span class="glyphicon glyphicon-save"></span> <?php _e('Save', 'mb'); ?>
				</button>
				<?php endif; ?>
			</span>
		</h2>
		<fieldset>
			<legend><?php _e('General Details', 'mb'); ?></legend>
			<div class="row">
				<div class="col-md-7">
					<div class="row">
						<div class="col-md-2">
							<div class="form-group">
								<label class="control-label"><?php _e('ID', 'mb'); ?></label>
								<input type="text" id="supplier_id" name="supplier_id" value="<?php print isset($purchase) ? $purchase->supplier_id : ''; ?>" class="form-control" />
							</div>
						</div>
						<div class="col-md-7">
							<div class="form-group">
								<label class="control-label"><?php _e('Provider', 'mb'); ?></label>
								<input type="text" id="supplier_name" name="supplier_name" 
									value="<?php print isset($purchase) ? $purchase->supplier->supplier_name : ''; ?>" class="form-control" />
							</div>
						</div>
						<div class="">
							<div class="form-group">
								<label>&nbsp;</label>
								<div>
									<a href="javascript:;" id="btn-search-provider" class="btn btn-default" title="<?php _e('Search provider', 'mb'); ?>">
										<span class="glyphicon glyphicon-search"></span>
									</a>
									<a href="javascript:;" id="btn-add-provider" class="btn btn-default" title="<?php _e('Create provider', 'mb'); ?>"
										data-toggle="modal" data-target="#create-provider-modal">
										<span class="glyphicon glyphicon-user"></span>
									</a>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<p id="customer-address"></p>
						<div class="col-md-3"><span id="supplier-rfc"></span></div>
						<div class="col-md-3"><span id="supplier-email"></span></div>
						<div class="col-md-3"><span id="supplier-phone"></span></div>
					</div>
					<div class="row">
						<div class="col-md-4">
							<div class="form-group">
								<label><?php _e('Store', 'mb'); ?></label>
								<select name="store_id" class="form-control">
									<option value="-1"><?php _e('-- store --', 'quotes'); ?></option>
									<?php foreach($stores as $s): ?>
									<option value="<?php print $s->store_id; ?>" <?php print isset($purchase) && $purchase->store_id == $s->store_id ? 'selected' : ''; ?>>
										<?php print $s->store_name; ?>
									</option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<?php /*
						<div class="col-md-4">
							<div class="form-group">
								<label><?php _e('Apply Promo', 'quotes'); ?></label>
								<select name="coupon_id" class="form-control">
									<option value="-1"><?php _e('-- coupon --'); ?></option>
									<?php foreach($coupons as $c): ?>
									<option value="<?php print $c->coupon_id; ?>"><?php print $c->description; ?></option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						<div class="col-md-4">
							<div class="form-group">
								<label><?php _e('Taxes', 'quotes'); ?></label>
								<select name="tax_id" class="form-control">
									<option value="-1"><?php _e('-- taxes --', 'quotes'); ?></option>
									<?php foreach($taxes as $t): ?>
									<option value="<?php print $t->tax_id; ?>">
										<?php printf("%s (%.2f)", $t->name, $t->rate); ?>
									</option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
						*/?>
					</div>
					<div class="row">
						<div class="col-md-3">
							<label><?php _e('Invoice Num.', 'mb'); ?></label>
							<input type="text" name="meta[_invoice_num]" value="<?php print isset($purchase) ? $purchase->_invoice_num : ''; ?>" class="form-control" />
						</div>
						<div class="col-md-3">
							<label><?php _e('Date', 'mb'); ?></label>
							<input type="text" name="order_date" value="<?php print isset($purchase) ? sb_format_date($purchase->order_date) : sb_format_date(time()); ?>" 
									class="form-control datepicker" />
						</div>
					</div>
				</div>
				<div class="col-md-5">
					<!-- 
					<div class="text-right">
						<?php _e('Order No.', 'mb');?><br/>
						<span id="order-number" class="text-red">
							<b><?php print isset($purchase) ? sb_fill_zeros($purchase->order_id) : 'C-000??'; ?></b>
						</span>
					</div>
					 -->
					<table id="table-totals" class="totals-table" style="width:100%;">
					<tr>
						<th class="text-right"><?php _e('Sub Total:', 'mb'); ?></th>
						<td class="text-right"><span id="quote-subtotal"><?php print isset($purchase) ? $purchase->subtotal : 0.00; ?></span></td>
					</tr>
					<tr>
						<th class="text-right"><?php _e('Discount:', 'mb'); ?></th>
						<td class="text-right"><span id="quote-discount"><?php print isset($purchase) ? $purchase->discount : 0.00; ?></span></td>
					</tr>
					<tr>
						<th class="text-right"><?php _e('Tax:', 'mb'); ?></th>
						<td class="text-right"><span id="quote-tax"><?php print isset($purchase) ? $purchase->total_tax : 0.00; ?></span></td>
					</tr>
					<tr>
						<th class="text-right"><b><?php _e('Advance:', 'mb'); ?></b></th>
						<td class="text-right"><b><span id="invoice-total">0.00</span></b></td>
					</tr>
					<tr id="row-total">
						<th class="text-right"><?php _e('Grand Total:', 'mb'); ?></th>
						<td class="text-right"><span id="quote-total"><?php print isset($purchase) ? $purchase->total : 0.00; ?></span></td>
					</tr>
					</table>
				</div>
			</div>
		</fieldset><br/>
		<div class="form-group">
			<div class="input-group">
				<input type="text" id="search_product" name="search_product" value="" placeholder="<?php print SBText::_('Search product', 'invoice'); ?>" class="form-control" />
				<span class="input-group-btn">
		        	<button id="btn-add-item" class="btn btn-default" type="button"><?php print SBText::_('Add item', 'quotes'); ?></button>
		      	</span>
			</div>
		</div>
		<table id="purchase-table" class="table table-condensed form-group-sm">
			<thead>
			<tr>
				<th class="text-center"><?php _e('No.', 'quotes'); ?></th>
				<th class="text-center"><?php print SBText::_('Code', 'quotes'); ?></th>
				<th class="column-product"><?php print SBText::_('Product', 'quotes'); ?></th>
				<th class="column-qty"><?php print SBText::_('Quantity', 'quotes'); ?></th>
				<th class="column-price text-right"><?php print SBText::_('Price', 'quotes'); ?></th>
				<th class="column-total text-right"><?php print SBText::_('Total', 'quotes'); ?></th>
				<th>&nbsp;</th>
			</tr>
			</thead>
			<tbody>
			<?php if( isset($purchase) ): $i = 1; foreach($purchase->GetItems() as $item): ?>
			<tr>
				<td><?php print $i; ?></td>
				<td><input type="text" name="items[<?php print $i - 1; ?>][code]" value="<?php print $item->product_code; ?>" class="form-control" /></td>
				<td class="column-product"><input type="text" name="items[<?php print $i - 1; ?>][name]" value="<?php print $item->name ?>" class="form-control" /></td>
				<td class="text-center">
					<input type="number" min="1" name="items[<?php print $i - 1; ?>][qty]" value="<?php print $item->quantity ?>" class="form-control item-qty" />
				</td>
				<td class="column-price"><input type="text" name="items[<?php print $i - 1; ?>][price]" value="<?php print $item->supply_price ?>" class="form-control item-price" /></td>
				<td><?php print $item->total ?></td>
				<td>
					<a href="javascript:;" class="remove-item btn btn-default" title="<?php _e('Delete', 'mb'); ?>">
						<span class="glyphicon glyphicon-trash"></span>
					</a>
				</td>
			</tr>
			<?php $i++; endforeach; endif; ?>
			</tbody>
		</table><!-- end id="quote-table" -->
		<br/>
		<hr class="ht--"/>
		<div class="form-group">
			<label><?php _e('Notes', 'mb'); ?></label>
			<textarea name="notes" class="form-control"><?php print isset($purchase) ? $purchase->details : ''; ?></textarea>
		</div>
		<style>
		.inv-item-remove{width:5%;text-align:center;}
		.inv-item-remove img{width:25px;}
		.inv-item-number{width:7.5%;}
		.inv-item-name{width:50%;}
		.inv-item-qty{width:10%;}
		.inv-item-price{width:12.5%;}
		.inv-item-tax{width:12.5%;}
		.inv-item-total{width:15%;}
		.cool-table{background:#fff;}
		.cool-table .body{max-height:250px;}
		.cool-table .inv-item-number, .cool-table .inv-item-qty{text-align:center;}
		.cool-table .inv-item-qty input{text-align:center;}
		.cool-table .inv-item-price input, .cool-table .inv-item-tax input{text-align:right;}
		.cool-table .inv-item-total{text-align:right;}
		.table .column-product{width:45%;}
		.table .column-price input{text-align:right;}
		.sb-suggestions{max-height:200px;width:100%;}
		.sb-suggestions .the_suggestion{padding:5px;display:block;}
		.sb-suggestions .the_suggestion:focus,
		.sb-suggestions .the_suggestion:hover{background:#ececec;text-decoration:none;}, 
		</style>
	</form>
</div>
<!-- Modal -->
<div class="modal fade" id="search-provider-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
	<div class="modal-dialog modal-dialog-lg" role="document">
	    <div class="modal-content">
			<div class="modal-header">
	        	<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        	<h4 class="modal-title" id="myModalLabel"><?php _e('Search Provider', 'customers'); ?></h4>
	      	</div>
	      	<div class="modal-body">
	      		<iframe src="<?php print SB_Route::_('index.php?mod=mb&view=providers_list&tpl_file=module'); ?>" style="width:100%;height:300px;" frameborder="0"></iframe>
	      	</div>
	      	<div class="modal-footer">
	        	<button type="button" class="btn btn-default" data-dismiss="modal"><?php _e('Close', 'customers'); ?></button>
	      	</div>
	    </div>
  	</div>
</div>
<div class="modal fade" id="create-provider-modal" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-dialog-lg" role="document">
	    <div class="modal-content">
			<div class="modal-header">
	        	<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        	<h4 class="modal-title"><?php _e('Create Provider', 'customers'); ?></h4>
	      	</div>
	      	<div class="modal-body">
	      		<iframe src="<?php print SB_Route::_('index.php?mod=provider&view=new_prov&tpl_file=module'); ?>" style="width:100%;height:300px;" 
	      				frameborder="0"></iframe>
	      	</div>
	      	<div class="modal-footer">
	        	<button type="button" class="btn btn-default" data-dismiss="modal"><?php _e('Close', 'quotes'); ?></button>
	      	</div>
	    </div>
  	</div>
</div>
<?php if( isset($purchase) ): ?>
<div class="modal fade" id="send-quote-form" tabindex="-1" role="dialog"><form action="" method="post">
	<div class="modal-dialog" role="document">
	    <div class="modal-content">
			<div class="modal-header">
	        	<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	        	<h4 class="modal-title"><?php _e('Send Quotation', 'customers'); ?></h4>
	      	</div>
	      	<div class="modal-body">
      			<input type="hidden" name="mod" value="quotes" />
      			<input type="hidden" name="task" value="send" />
      			<?php if( isset($quote) ): ?>
      			<input type="hidden" name="id" value="<?php print $quote->quote_id; ?>" />
      			<?php endif; ?>
      			<div class="form-group">
      				<input type="text" name="email_to" value="<?php print $quote->customer->email; ?>" placeholder="<?php _e('Email', 'quotes'); ?>" class="form-control" />
      			</div>
      			<div class="form-group">
      				<input type="text" name="subject" value="" placeholder="<?php _e('Email subject', 'quotes'); ?>" class="form-control" />
      			</div>
      			<div class="form-group">
      				<textarea rows="" cols="" name="message" placeholder="<?php _e('Quote message', 'quoes'); ?>" class="form-control"></textarea>
      			</div>
	      	</div>
	      	<div class="modal-footer">
	        	<button type="button" class="btn btn-default" data-dismiss="modal"><?php _e('Close', 'quotes'); ?></button>
	        	<button type="submit" class="btn btn-primary"><?php _e('Send Quote', 'quotes'); ?></button> 
	      	</div>
	    </div>
  	</form></div>
</div>
<?php endif; ?>