<?php
class LT_AdminControllerMb extends SB_Controller
{
	public function task_default()
	{
		$user = sb_get_current_user();
		/*
		$dbh = SB_Factory::getDbh();
		$query = "SELECT * FROM mb_products ORDER BY creation_date DESC";
		$dbh->Query($query);
		$products = $dbh->FetchResults();
		$products = SB_Warehouse::getStoreProducts($store_id = null);
		sb_set_view_var('products', $products);
		*/
		if( $user->role_id !== 0 && !$user->_store_id && $user->role_key != 'superadmin' )
		{
			lt_die(__('You dont have any store assigned', 'mb'));
		}
		$store_id	= SB_Request::getInt('store_id');
		$cat_id		= SB_Request::getInt('category_id');
		$type_id	= SB_Request::getInt('type_id');
		$filter 	= SB_Request::getString('filter');
		$where 		= array();
		if( !$user->can('mb_see_all_stores') )
		{
			$store_id = (int)$user->_store_id;
		}
		if( $filter == null )
		{
			//$keyword = SB_Request::getString('keyword');
			
			$columns = array('*');
			$table = array('mb_products p');
			if( $store_id > 0 )
			{
				$where[] = "p.store_id = $store_id";
			}
			if( $cat_id > 0 )
			{
				$table[] = 'mb_product2category p2c';
				$where[] = 'p.product_id = p2c.product_id';
				$where[] = 'p2c.category_id = ' . $cat_id;
			}
			$order_by = SB_Request::getString('order_by', "p.product_name");
			
			if( $type_id > 0 )
			{
				$where[] = "p.type_id = $type_id";
			}
			$products = sb_get_navigation($order_by, 'SB_MBProduct', $columns, $table, $where, null, 'asc');
			sb_set_view_var('stores', SB_Warehouse::GetUserStores($user));
			sb_set_view_var('title', SBText::_('Products', 'mb'));
			sb_set_view_var('products', $products);
			sb_set_view_var('def_search_text', __('Name', 'mb'));
			if( $cat_id > 0 )
			{
				sb_set_view_var('categories', SB_Warehouse::getCategories($store_id));
			}
		}
		else 
		{
			if( $filter == 'null' )
			{
				sb_set_view_var('title', '<div class="alert alert-warning">' . __('Products without minimal quantity assigned', 'mb') . '</div>');
				sb_set_view_var('keyword', '');
				sb_set_view_var('total_pages', 1);
				sb_set_view_var('current_page', 1);
				sb_set_view_var('products', SB_Warehouse::GetProductsWithNullMinQty());
				sb_set_view_var('def_search_text', SBText::_('Name', 'mb'));
			}
			elseif( $filter == 'warning' )
			{
				sb_set_view_var('title', '<div class="alert alert-warning">' . __('Products with minimal quantity warning', 'mb') . '</div>');
				sb_set_view_var('keyword', '');
				sb_set_view_var('total_pages', 1);
				sb_set_view_var('current_page', 1);
				sb_set_view_var('products', SB_Warehouse::GetProductsWithMinQtyWarning());
				sb_set_view_var('def_search_text', SBText::_('Name', 'mb'));
			}
			elseif( $filter == 'zero' )
			{
				sb_set_view_var('title', '<div class="alert alert-danger">' . __('Products with quantity danger', 'mb') . '</div>');
				sb_set_view_var('keyword', '');
				sb_set_view_var('total_pages', 1);
				sb_set_view_var('current_page', 1);
				sb_set_view_var('products', SB_Warehouse::GetProductsWithZeroQty());
				sb_set_view_var('def_search_text', SBText::_('Name', 'mb'));
			}
		}
		sb_set_view_var('user', $user);
		sb_set_view_var('store_id', $store_id);
		sb_set_view_var('types', SB_Warehouse::getTypes());
		sb_add_style('default', MOD_MB_URL . '/css/default.css');
		sb_add_script(BASEURL . '/js/camera.js', 'camera');
		sb_add_script(BASEURL . '/js/get_barcode_from_image.js', 'barcode');
	}
	public function task_new_product()
	{
		$user = sb_get_current_user();
		if( !$user->can('mb_create_product') )
		{
			lt_die(__('You dont have enough permissions to create products', 'mb'));
		}
		$title = __('New Product', 'mb');
		sb_set_view_var('categories', SB_Warehouse::getCategories());
		sb_set_view_var('types', SB_Warehouse::GetProductTypes());
		sb_set_view_var('title', SBText::_('Create New Product'));
		sb_set_view_var('stores', SB_Warehouse::getStores());
		sb_set_view_var('measurement_units', SB_Warehouse::GetMeasurementUnits());
		sb_set_view_var('types', SB_Warehouse::GetProductTypes());
		sb_add_style('new-product', MOD_MB_URL . '/css/new-product.css');
		sb_add_style('fine-uploaders', BASEURL . '/js/fineuploader/uploader.css');
		sb_add_script(BASEURL . '/js/fineuploader/all.fine-uploader.min.js', 'fine-uploader');
		sb_set_view_var('upload_endpoint', SB_Route::_('index.php?mod=mb&task=upload_image'));
		sb_set_view_var('extensions', array('jpg', 'jpeg', 'gif', 'bmp', 'png'));
		
		if( $base_type = SB_Request::getString('btype') )
		{
			sb_set_view_var('base_type', $base_type);
		}
		sb_set_view_var('user', $user);
		if( (isset($_SERVER['HTTP_REFERER']) && strstr($_SERVER['HTTP_REFERER'], 'keyword')) || SB_Session::getVar('search_link') )
		{
			if( $search_link = SB_Session::getVar('search_link') )
			{
				sb_set_view_var('search', $search_link);
			}
			else
			{
				SB_Session::setVar('search_link', $_SERVER['HTTP_REFERER']);
				sb_set_view_var('search', $_SERVER['HTTP_REFERER']);
			}
			
		}
		//##restart session images for a new product
		SB_Session::unsetVar('product_images');
		$this->document->SetTitle($title);
	}
	public function task_edit()
	{
		$user = sb_get_current_user();
		if( !$user->can('mb_view_product') )
		{
			lt_die(__('You cant view or edit the product', 'mb'));
		}
		$id = SB_Request::getInt('id');
		$p = new SB_MBProduct($id);
		if( !$p->product_id )
		{
			SB_MessagesStack::AddMessage(__('The product does not exists', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb'));
		}
		$title = __('Edit Product', 'mb');
		sb_set_view('new_product');
		$p = SB_Module::do_action('mb_edit_product', $p);
		sb_set_view_var('user', $user);
		sb_set_view_var('title', $title);
		sb_set_view_var('the_product', $p);
		sb_set_view_var('stores', SB_Warehouse::getStores());
		sb_set_view_var('categories', SB_Warehouse::getCategories($p->store_id));
		sb_set_view_var('types', SB_Warehouse::GetProductTypes());
		sb_set_view_var('measurement_units', SB_Warehouse::GetMeasurementUnits());
		sb_set_view_var('base_type', $p->base_type);
		sb_add_style('new-product', MOD_MB_URL . '/css/new-product.css');
		sb_add_style('fine-uploaders', BASEURL . '/js/fineuploader/uploader.css');
		sb_add_script(BASEURL . '/js/fineuploader/all.fine-uploader.min.js', 'fine-uploader');
		sb_set_view_var('upload_endpoint', SB_Route::_('index.php?mod=mb&task=upload_image&id='.$p->product_id));
		sb_set_view_var('extensions', array('jpg', 'jpeg', 'gif', 'bmp', 'png'));
		if( (isset($_SERVER['HTTP_REFERER']) && strstr($_SERVER['HTTP_REFERER'], 'keyword')) || SB_Session::getVar('search_link') )
		{
			if( $search_link = SB_Session::getVar('search_link') )
			{
				sb_set_view_var('search_link', $search_link);
			}
			else
			{
				SB_Session::setVar('search_link', $_SERVER['HTTP_REFERER']);
				sb_set_view_var('search_link', $_SERVER['HTTP_REFERER']);
			}
				
		}
		$this->document->SetTitle($title);
	}
	public function task_delete()
	{
		if( !sb_is_user_logged_in() )
		{
			lt_die(__('You need to start a session', 'mb'));
		}
		if( !sb_get_current_user()->can('mb_delete_product') )
		{
			SB_MessagesStack::AddMessage(__('You are not authorized to delete a product.', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb'));
		}
		$id = SB_Request::getInt('id');
		if( !$id )
		{
			SB_MessagesStack::AddMessage(__('The product id is invalid', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb'));
		}
		$prod = new SB_MBProduct($id);
		if( !$prod->product_id )
		{
			SB_MessagesStack::AddMessage(__('The product does not exists', 'mb'), 'error');
			sb_redirect(SB_Route::_('index.php?mod=mb'));
		}
		$this->dbh->Delete('mb_product_meta', array('product_id' => $id));
		$this->dbh->Delete('mb_product2category', array('product_id' => $id));
		$this->dbh->Delete('mb_product2suppliers', array('product_id' => $id));
		$this->dbh->Delete('mb_product2tag', array('product_id' => $id));
		$this->dbh->Delete('mb_products', array('product_id' => $id));
		SB_MessagesStack::AddMessage(__('The product has been deleted', 'mb'), 'error');
		sb_redirect(isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : SB_Route::_('index.php?mod=mb'));
	}
	public function task_save()
	{
		$user = sb_get_current_user();
		
		$id = SB_Request::getInt('id');
		if( !$id && !$user->can('mb_create_product') )
		{
			lt_die(__('You cant edit the product', 'mb'));
		}
		elseif( $id && !$user->can('mb_edit_product') )
		{
			lt_die(__('You cant edit the product', 'mb'));
		}
		$product_code 			= SB_Request::getString('product_code');
		$product_name 			= SB_Request::getString('product_name');
		$product_description 	= SB_Request::getString('description');
		$product_cost			= SB_Request::getFloat('product_cost');
		$product_price			= SB_Request::getFloat('product_sale_price');
		$product_price_2		= SB_Request::getFloat('product_sale_price_2');
		$product_price_3		= SB_Request::getFloat('product_sale_price_3');
		$product_price_4		= SB_Request::getFloat('product_sale_price_4');
		$store_id				= SB_Request::getInt('store_id');
		$type_id				= SB_Request::getInt('type_id');
		$product_quantity		= SB_Request::getInt('product_quantity');
		$min_stock				= SB_Request::getInt('min_stock');
		$stock_alert			= SB_Request::getInt('stock_alert');
		$product_unit_measure	= SB_Request::getInt('unit_measure');
		$for_sale				= SB_Request::getInt('for_sale');
		$status					= SB_Request::getString('status', 'publish');
		$base_type				= SB_Request::getString('base_type', 'base');
		$product_barcode		= SB_Request::getString('product_barcode');
		$product_number			= SB_Request::getString('product_serial_number');
		$cats = array(
				SB_Request::getInt('category_id')
		);
		$meta = array(
				'_discount' 	=> SB_Request::getFloat('product_discount'),
				'_stock_alert' 	=> $stock_alert
		);
		$meta = array_merge($meta, (array)SB_Request::getVar('meta', array()));
		if( empty($product_name) )
		{
			SB_MessagesStack::AddMessage(SBText::_('You need to enter a product name', 'mb'), 'error');
			return false;
		}
		$dbh = SB_Factory::getDbh();
		$data = compact('product_code', 
						'product_name', 
						'product_description', 
						'product_cost', 
						'product_price', 
						'product_price_2', 
						'product_price_3',
						'product_price_4',
						'store_id', 
						'type_id', 
						'product_quantity', 
						'min_stock', 
						'product_unit_measure', 
						'status', 
						'base_type',
						'for_sale',
						'product_barcode',
						'product_number'
		);
		if( !$id )
		{
			$data['creation_date'] = date('Y-m-d H:i:s');
			$id = $dbh->Insert('mb_products', $data);
			//##create initial kardex
			$this->dbh->Insert('mb_product_kardex', 
					array(
							'product_id' 			=> $id,
							'in_out'				=> 'input',
							'quantity'				=> $product_quantity,
							'quantity_balance'		=> $product_quantity,
							'unit_price'			=> $product_cost,
							'total_amount'			=> $product_quantity * $product_cost,
							'monetary_balance'		=> $product_quantity * $product_cost,
							'transaction_type_id'	=> -1,
							'author_id'				=> $user->user_id,
							'transaction_id'		=> -1,
							'creation_date'			=> date('Y-m-d H:i:s')
					));
			$msg = SBText::_('The product has been created', 'mb');
			$link = SB_Route::_('index.php?mod=mb');
			//##set product images
			$images = (array)SB_Session::getVar('product_images', array());
			if( count($images) )
			{
				$query = "UPDATE attachments SET object_id = $id WHERE attachment_id INT(".implode(',', $images).")";
				$this->dbh->Query($query);
			}
		}
		else
		{
			$dbh->Update('mb_products', $data, array('product_id' => $id));
			$msg = __('The product has been updated', 'mb');
			$link = SB_Route::_('index.php?mod=mb&view=edit&id='.$id);
		}
		//##delete product categories
		$dbh->Query("DELETE FROM mb_product2category WHERE product_id = $id");
		foreach($cats as $cat_id)
		{
			$dbh->Insert('mb_product2category', array('product_id' => $id, 'category_id' => $cat_id));
		}
		//##add product meta
		foreach($meta as $meta_key => $meta_value)
		{
			mb_update_product_meta($id, $meta_key, $meta_value);
		}
		SB_Module::do_action('mb_save_product', $id, $data);
		SB_MessagesStack::AddMessage($msg, 'success');
		sb_redirect($link);
	}
	public function task_ajax()
	{
		$action = SB_Request::getString('action');
		if( $action == 'get_store_cats' )
		{
			$store_id = SB_Request::getInt('store_id');
			$cats = SB_Warehouse::getCategories($store_id);
			sb_response_json(array('status' => 'ok', 'categories' => $cats));
		}
		if( $action == 'get_store_types' )
		{
			$store_id = SB_Request::getInt('store_id');
			$types = SB_Warehouse::GetProductTypes($store_id);
			sb_response_json($types);
		}
		if( $action == 'test' )
		{
			$store_id = SB_Request::getInt('store_id');
			$cats = SB_Warehouse::getCategories($store_id);
			$res = sb_json_encode(array('status' => 'ok', 'categories' => $cats));
			die($res);
		}
		if( $action == 'get_product' )
		{
			$id = SB_Request::getInt('id');
			$prod = new SB_MBProduct($id);
			if( !$prod->product_id )
			{
				sb_response_json(array('status' => 'error', 'error' => __('The product does not exists', 'mb')));
			}
			sb_response_json(array('status' => 'ok', 'product' => $prod));
		}
		if( $action == 'search_product' )
		{
			$keyword 	= SB_Request::getString('keyword');
			$store_id 	= SB_Request::getInt('store_id');
			$cols		= array(
					'product_id AS id', 
					'product_id',
					'product_code', 
					'product_name AS name', 
					'CONCAT(product_code, \' - \',product_name) AS label',
					'product_quantity', 
					'product_cost',
					'product_price',
					'product_price_2',
					'product_price_3',
					'product_price_4'
			);
			$query = sprintf("SELECT %s ", implode(',', $cols)) .
						"FROM mb_products ".
						"WHERE product_name LIKE '%$keyword%' ";
			if( $store_id > 0 )
			{
				$query .= "AND store_id = $store_id ";
			}
			$query .= "ORDER BY product_name";
			$rows = $this->dbh->FetchResults($query);
			for($i = 0; $i < count($rows); $i++ )
			{
				$rows[$i]->label = $rows[$i]->product_quantity <= 0  ? 
										'<span class="text-danger">' . $rows[$i]->label . '</span>' : 
										'<span class="text-success">' . $rows[$i]->label . '</span>';
			}
			sb_response_json(array('status' => 'ok', 'results' => $rows));
		}
		if( $action == 'generate_barcode' )
		{
			$res = array('status' => 'ok');
			$id = SB_Request::getInt('id');
			if( !$id )
			{
				$res['status'] = 'error';
				$res['error'] = __('Invalid product identifier', 'mb');
				sb_response_json($res);
			}
			require_once INCLUDE_DIR . SB_DS . 'classes' . SB_DS . 'class.barcode.php';
			$mb_settings = (object)sb_get_parameter('mb_settings', new stdClass());
			$res['barcode'] = SB_BarcodeEAN13::Build($mb_settings->barcode_ean13_country, $mb_settings->barcode_ean13_company, $id);
			sb_response_json($res);
		}
		if( $action == 'get_warehouses' )
		{
			$store_id = SB_Request::getInt('store_id');
			$query = "SELECT * FROM mb_warehouse WHERE store_id = $store_id ORDER BY name ASC";
			$res = array(
					'status'	=> 'ok',
					'items'		=> SB_Factory::getDbh()->FetchResults($query)
			);
			sb_response_json($res);
		}
		if( $action == 'get_batches' )
		{
			$res = array(
					'status'	=> 'ok',
					'items'		=> SB_Warehouse::GetBatches() 
			);
			sb_response_json($res);
		}
	}
	public function task_do_import()
	{
		set_time_limit(0);
		$store_id 		= SB_Request::getInt('store_id');
		$category_id 	= SB_Request::getInt('category_id');
		$sep 			= SB_Request::getString('separator', ',');
		$file_type		= SB_Request::getString('file_type');
		if( SB_Request::getInt('ta') )
		{
			$this->dbh->Query("TRUNCATE mb_categories");
			$this->dbh->Query("TRUNCATE mb_products");
			$this->dbh->Query("TRUNCATE mb_product2category");
			die(__FILE__);
		}
		//##check for update prices only
		if( $file_type == 'xls_file' && SB_Request::getInt('update_prices_only') )
		{
			$this->task_update_prices();
			return;
		}
		if( $store_id <= 0 )
		{
			SB_MessagesStack::AddMessage(SBText::_('You need to select a store', 'mb'), 'error');
			return false;
		}
		if( !isset($_FILES['the_file']) )
		{
			SB_MessagesStack::AddMessage(SBText::_('You need to select a file'), 'error');
			return false;
		}
		if( $_FILES['the_file']['size'] <= 0 )
		{
			SB_MessagesStack::AddMessage(SBText::_('Error uploading file'), 'error');
			return false;
		}
		if( !$file_type )
		{
			SB_MessagesStack::AddMessage(SBText::_('You need to select a file type', 'mb'), 'error');
			return false;
		}
		$mimes = array(
				'text/csv',
				'text/xls'
		);
		if( $file_type == 'monobusiness_csv' && !in_array($_FILES['the_file']['type'], $mimes) )
		{
			SB_MessagesStack::AddMessage(SBText::_('The file is not a CSV.'), 'error');
			return false;
		}
		
		$updated = $i = 0;
		if( $file_type == 'monobusiness_csv' )
		{
			$products = array();
			$fh = fopen($_FILES['the_file']['tmp_name'], 'r');
			$headers = explode($sep, fgets($fh));
			if( count($headers) < 4 )
			{
				SB_MessagesStack::AddMessage(SBText::_('Invalid CSV separator'), 'error');
				return false;
			}
			$i = 0;
			while( $line = fgets($fh) )
			{
				$data = array_map(create_function('$el', "return trim(\$el, '\"');"), explode($sep, $line));
				$products[] = array(
						'extern_id'			=> $data[0],
						'product_code'		=> $data[1],
						'product_name'		=> $data[2],
						'product_cost'		=> $data[4],
						'product_price'		=> $data[5],
						'product_price_2'	=> $data[6],
						'product_price_3'	=> $data[7],
						'product_quantity'	=> $data[3],
						'store_id'			=> $store_id
				);
				$i++;
			}
			fclose($fh);
			$dbh = SB_Factory::getDbh();
			$dbh->InsertBulk('mb_products', $products);
		}
		elseif( $file_type == 'monobusiness_file' )
		{
			//##include database driver for sqlite
			sb_include('database' . SB_DS . 'database.sqlite3.php', 'file');
			$destination = TEMP_DIR . SB_DS . basename($_FILES['the_file']['tmp_name']);
			move_uploaded_file($_FILES['the_file']['tmp_name'], $destination);
			$sqlite = new SB_Sqlite3($destination);
			//##get sqlite categories
			$query = "SELECT * FROM categories";
			foreach($sqlite->FetchResults($query) as $cat)
			{
				//##check if category already exists
				if( !$this->dbh->Query("SELECT category_id FROM mb_categories WHERE extern_id = $cat->category_id AND store_id = $store_id LIMIT 1") )
				{
					$data = array(
							'name' 			=> $cat->name,
							'description' 	=> $cat->description,
							'extern_id'		=> $cat->category_id,
							'store_id'		=> $store_id,
							'creation_date'	=> date('Y-m-d H:i:S')
					);
					$this->dbh->Insert('mb_categories', $data);
				}
			}
			//##get local categories
			$categories = array();
			foreach($this->dbh->FetchResults("SELECT * FROM mb_categories WHERE store_id = $store_id") as $row)
			{
				$categories['_'.$row->extern_id] = $row; 
			}
			//##get products from sqlite
			$query = "SELECT p.*, p2c.category_id, ".
							"(SELECT c.name FROM categories c WHERE c.category_id = p2c.category_id) as category ".
						"FROM products p " .
						"LEFT JOIN product2category p2c ON p.product_id = p2c.product_id " .
						"WHERE 1 = 1 ";
			$items = $sqlite->FetchResults($query);
			foreach($items as $item)
			{
				$row = $this->dbh->FetchRow("SELECT product_id FROM mb_products WHERE extern_id = $item->product_id AND store_id = $store_id LIMIT 1");
				if( !$row )
				{
					$data = array(
							'extern_id'				=> $item->product_id,
							'product_code'			=> $item->product_code,
							'product_name'			=> $item->product_name,
							'product_description'	=> $item->product_description,
							'product_cost'			=> $item->product_cost,
							'product_price'			=> $item->product_price,
							'product_price_2'		=> $item->product_price_2,
							'product_price_3'		=> $item->product_price_3,
							//'product_price_4'		=> $item->product_price_4,
							'product_quantity'		=> $item->product_quantity,
							'store_id'				=> $store_id,
							'status'				=> $item->status,
							'min_stock'				=> $item->min_stock,
							'creation_date'			=> date('Y-m-d H:i:s')
					);
					$new_id = $this->dbh->Insert('mb_products', $data);
					$row = (object)array('product_id' => $new_id);
				}
				//##update the product data
				else 
				{
					$data = array(
							'product_cost'			=> $item->product_cost,
							'product_price'			=> $item->product_price,
							'product_price_2'		=> $item->product_price_2,
							'product_price_3'		=> $item->product_price_3,
							//'product_price_4'		=> $item->product_price_4,
							'product_quantity'		=> $item->product_quantity,
							'store_id'				=> $store_id,
							'min_stock'				=> $item->min_stock,
					);
					$this->dbh->Update('mb_products', $data, array('product_id' => $row->product_id));
				}
				//##set product categories
				$this->dbh->Query("DELETE FROM mb_product2category WHERE product_id = $row->product_id");
				$this->dbh->Insert('mb_product2category', 
									array(
											'category_id' => $categories['_'.$item->category_id]->category_id,
											'product_id'	=> $row->product_id				
									)
				);
				$i++;
			}
			$sqlite->Close();
		}
		elseif( $file_type == 'xls_file' )
		{
			$sheet_num		= SB_Request::getInt('sheet_num');
			$row_start		= SB_Request::getInt('row_start', 1);
			$code_column 	= SB_Request::getInt('code_column');
			$name_column 	= SB_Request::getInt('name_column');
			$qty_column 	= SB_Request::getInt('qty_column');
			$cost_column	= SB_Request::getInt('cost_column', -1);
			$price_column	= SB_Request::getInt('price_column', -1);
			$price_column_2	= SB_Request::getInt('price_column_2', -1);
			$price_column_3	= SB_Request::getInt('price_column_3', -1);
			$price_column_4	= SB_Request::getInt('price_column_4', -1);
			
			//$sheet_num--;
			if( $sheet_num < 0 )
				$sheet_num = 0;
			if( $sheet_num > 0 )
				$sheet_num--;
			
			sb_include_lib('php-office/PHPExcel-1.8/PHPExcel/IOFactory.php');
			sb_include_lib('php-office/PHPExcel-1.8/PHPExcel.php');
			$xls 		= PHPExcel_IOFactory::load($_FILES['the_file']['tmp_name']);
			$sheet 		= $xls->setActiveSheetIndex($sheet_num);
			//$sheet = $xls->getActiveSheet();
			//$sheet 		= (!$sheet_num) ? $xls->getActiveSheet() : $xls->getSheet($sheet_num);
			$total_rows = $sheet->getHighestRow();
			$total_cols = $sheet->getHighestColumn();
			/*
			var_dump('sheet => ' . $sheet_num);
			var_dump('row_start => ' . $row_start);
			var_dump('total_rows => ' . $total_rows);die();
			*/
			for($row = $row_start; $row <= $total_rows; $row++)
			{
				$product_code 	= trim($sheet->getCellByColumnAndRow($code_column, $row)->getCalculatedValue());
				$product_name 	= trim($sheet->getCellByColumnAndRow($name_column, $row)->getCalculatedValue());
				$product_qty 	= (int)trim($sheet->getCellByColumnAndRow($qty_column, $row)->getCalculatedValue());
				$product_cost	= $cost_column != -1 ? $sheet->getCellByColumnAndRow($cost_column, $row)->getCalculatedValue() : 0;
				$product_price	= $price_column != -1 ? $sheet->getCellByColumnAndRow($price_column, $row)->getCalculatedValue() : 0;
				$product_price_2	= $price_column_2 != -1 ? $sheet->getCellByColumnAndRow($price_column_2, $row)->getCalculatedValue() : 0;
				$product_price_3	= $price_column_3 != -1 ? $sheet->getCellByColumnAndRow($price_column_3, $row)->getCalculatedValue() : 0;
				$product_price_4	= $price_column_4 != -1 ? $sheet->getCellByColumnAndRow($price_column_4, $row)->getCalculatedValue() : 0;
				
				$data = array(
						'product_code' 				=> $product_code,
						'product_name' 				=> $product_name,
						'product_description' 		=> '',
						'product_cost' 				=> $product_cost,
						'product_price' 			=> $product_price,
						'product_price_2' 			=> $product_price_2,
						'product_price_3' 			=> $product_price_3,
						'product_price_4' 			=> $product_price_4,
						'store_id'					=> $store_id,
						'type_id'					=> 0,
						'product_quantity'			=> $product_qty,
						'min_stock'					=> 1,
						'product_unit_measure' 		=> 0,
						'status'					=> 'publish',
						'base_type'					=> 'base',
						'for_sale'					=> 1,
						'product_barcode'			=> '',
						'product_number'			=> ''
				);
				//var_dump($row_start);
				$id = null;
				if( $p = SB_Warehouse::GetProductBy('code', $product_code, $store_id) )
				{
					$id = $p->product_id;
					$data = array();
					if( $product_qty > 0 )
						$data['product_quantity'] = $product_qty;
					if( $product_cost > 0 )
						$data['product_cost'] = $product_cost;
					if( $product_price > 0 )
						$data['product_price'] = $product_price;
					if( $product_price_2 > 0 )
						$data['product_price_2'] = $product_price_2;
					if( $product_price_3 > 0 )
						$data['product_price_3'] = $product_price_3;
					if( $product_price_4 > 0 )
						$data['product_price_4'] = $product_price_4;
					if( count($data) )
					{
						//##update the product
						$this->dbh->Update('mb_products', $data, array('product_id' => $id));
						$updated++;
					}
					
				}
				else
				{
					//##insert a new product
					$data['creation_date'] = date('Y-m-d H:i:s');
					$id = $this->dbh->Insert('mb_products', $data);
					$i++;
					//##set featured image
					$aid = lt_insert_attachment(MOD_MB_PROD_IMAGE_DIR . SB_DS . strtoupper($product_code) . '.jpg',
							'product', $id,
							0,
							'image');
					mb_update_product_meta($id, '_featured_image', $aid);
				}
				//##check for product category
				if( $category_id > 0 )
				{
					$this->dbh->Query("DELETE FROM mb_product2category WHERE product_id = $id LIMIT 1");
					$this->dbh->Insert('mb_product2category', array('product_id' => $id, 'category_id' => $category_id));
				}
				
			}
		}
		SB_MessagesStack::AddMessage(sprintf(__('Import completed, there were %d imported and %d updated products.', 'mb'), $i, $updated), 'success');
		sb_redirect(SB_Route::_('index.php?mod=mb&view=import'));
	}
	public function task_update_prices()
	{
		$sheet_num		= SB_Request::getInt('sheet_num');
		$row_start		= SB_Request::getInt('row_start', 1);
		$code_column 	= SB_Request::getInt('code_column', -1);
		$cost_column	= SB_Request::getInt('cost_column', -1);
		$price_column	= SB_Request::getInt('price_column', -1);
		$price_column_2	= SB_Request::getInt('price_column_2', -1);
		$price_column_3	= SB_Request::getInt('price_column_3', -1);
		$price_column_4	= SB_Request::getInt('price_column_4', -1);
			
		$sheet_num--;
		if( $sheet_num < 0 )
			$sheet_num = 0;
		if( $sheet_num > 0 )
			$sheet_num--;
			
		sb_include_lib('php-office/PHPExcel-1.8/PHPExcel/IOFactory.php');
		sb_include_lib('php-office/PHPExcel-1.8/PHPExcel.php');
		$xls 		= PHPExcel_IOFactory::load($_FILES['the_file']['tmp_name']);
		$sheet 		= $xls->setActiveSheetIndex($sheet_num);
		$total_rows = $sheet->getHighestRow();
		/*
		var_dump($sheet_num);
		var_dump($row_start);
		var_dump($total_rows);
		die();
		*/
		$updated = 0;
		for($row = $row_start; $row <= $total_rows; $row++)
		{
			$product_code 		= trim($sheet->getCellByColumnAndRow($code_column, $row)->getCalculatedValue());
			$product_cost		= $cost_column != -1 ? $sheet->getCellByColumnAndRow($cost_column, $row)->getCalculatedValue() : 0;
			$product_price		= $price_column != -1 ? $sheet->getCellByColumnAndRow($price_column, $row)->getCalculatedValue() : 0;
			$product_price_2	= $price_column_2 != -1 ? $sheet->getCellByColumnAndRow($price_column_2, $row)->getCalculatedValue() : 0;
			$product_price_3	= $price_column_3 != -1 ? $sheet->getCellByColumnAndRow($price_column_3, $row)->getCalculatedValue() : 0;
			$product_price_4	= $price_column_4 != -1 ? $sheet->getCellByColumnAndRow($price_column_4, $row)->getCalculatedValue() : 0;
		
			
			if( $p = SB_Warehouse::GetProductBy('code', $product_code) )
			{
				$data = array();
				if( $product_cost > 0 )
					$data['product_cost'] = $product_cost;
				if( $product_price > 0 )
					$data['product_price'] = $product_price;
				if( $product_price_2 > 0 )
					$data['product_price_2'] = $product_price_2;
				if( $product_price_3 > 0 )
					$data['product_price_3'] = $product_price_3;
				if( $product_price_4 > 0 )
					$data['product_price_4'] = $product_price_4;
				if( count($data) )
				{
					//##update the product
					$this->dbh->Update('mb_products', $data, array('product_code' => $p->product_code));
					$updated++;
				}
			}
		}
		SB_MessagesStack::AddMessage(sprintf(__('Product prices update complete. Total updated: %d', 'mb'), $updated), 'success');
		sb_redirect(SB_Route::_('index.php?mod=mb&view=import'));
	}
	public function task_settings()
	{
		$ops = sb_get_parameter('mb_settings');
		sb_set_view_var('ops', $ops);
		$this->document->SetTitle(__('Mono Business Settings', 'mb'));
	}
	public function task_save_settings()
	{
		$prev_mb_settings = (array)sb_get_parameter('mb_settings', array());
		$ops = array_map('trim', SB_Request::getVar('ops'));
		$uploaded = false;
		if( isset($_FILES['business_logo']) && $_FILES['business_logo']['size'] > 0 )
		{
			$file_logo = sb_get_unique_filename($_FILES['business_logo']['name'], UPLOADS_DIR);
			$uploaded = move_uploaded_file($_FILES['business_logo']['tmp_name'], $file_logo);
			$ops['business_logo'] = basename($file_logo);
		}
		$ops = array_merge($prev_mb_settings, $ops);
		sb_update_parameter('mb_settings', $ops);
		//##get and override global settings
		$settings = (object)sb_get_parameter('settings', array());
		$settings->SITE_TITLE = $ops['business_name'];
		if( $uploaded )
		{
			$settings->SITE_LOGO = $ops['business_logo'];
		}
		sb_update_parameter('settings', $settings);
		SB_Module::do_action('mb_save_settings', $ops);
		SB_MessagesStack::AddMessage(__('Settings saved', 'mb'), 'success');
		sb_redirect(SB_Route::_('index.php?mod=mb&view=settings'));
	}
	public function task_providers_list()
	{
		$query = "SELECT * FROM mb_suppliers";
		$rows = $this->dbh->FetchResults($query);
		sb_set_view_var('rows', $rows);
	}
	public function task_upload_image()
	{
		$id = SB_Request::getInt('id');
		sb_include('qqFileUploader.php', 'file');
		$uh = new qqFileUploader();
		//$uh->allowedExtensions = array('jpg', 'jpeg', 'gif', 'png', 'bmp', 'psd', 'tiff', 'ai');
		$uh->inputName = 'qqfile';
		// If you want to use resume feature for uploader, specify the folder to save parts.
		$uh->chunksFolder 		= 'chunks';
		$res 					= $uh->handleUpload(MOD_MB_PROD_IMAGE_DIR);
		$filename 				= $uh->getUploadName();
		$aid 					= lt_insert_attachment(MOD_MB_PROD_IMAGE_DIR . SB_DS . $filename, 'product', $id, 0, 'image');
		$res['attachment_id'] 	= $aid;
		if( !$id )
		{
			$images = (array)SB_Session::getVar('product_images', array());
			$images[] = $aid;
			SB_Session::setVar('product_images', $images);
		}
		
		$res['url'] = UPLOADS_URL . '/products/' . $filename; 
		sb_response_json($res);
	}
	public function task_print_catalog()
	{
		set_time_limit(0);
		ini_set('memory_limit', '512M');
		$store_id = SB_Request::getInt('store_id');
		$products = array();
		$title = '';
		if( $store_id )
		{
			$store = new SB_MBStore($store_id);
			$products = SB_Warehouse::getStoreProducts($store_id);
			$title = sprintf(__('%s - Products Catalog', 'mb'), $store->store_name);
		}
		else 
		{
			$title = __('Products Catalog', 'mb');
			$query = "SELECT * FROM mb_products";
			foreach($this->dbh->FetchResults($query) as $row)
			{
				$p = new SB_MBProduct();
				$p->SetDbData($row);
				$products[] = $p;
			}
		}
		ob_start();
		include 'views/admin/reports/catalog.php';
		$html = ob_get_clean();
		$pdf = mb_get_pdf_instance($title);
		$pdf->AddPage();
		$pdf->writeHTML($html, true, false, true, false, '');
		$pdf->Output(sprintf(__('products-catalog-%s.pdf'), sb_format_date(date('Y-m-d'))), 'I');
		die();
	}
	public function task_print_labels()
	{
		set_time_limit(0);
		ini_set('memory_limit', '512M');
		$store_id = SB_Request::getInt('store_id');
		$cat_id		= SB_Request::getInt('category_id');
		$products = array();
		$title = '';
		/*if( $cat_id )
		{
			$store = new SB_MBStore($store_id);
			$title = sprintf(__('%s - Products Catalog', 'mb'), $store->store_name);
			
		}
		else*/if( $store_id )
		{
			$store = new SB_MBStore($store_id);
			$products = SB_Warehouse::getStoreProducts($store_id);
			$title = sprintf(__('%s - Products Catalog', 'mb'), $store->store_name);
		}
		else
		{
			$title = __('Products Catalog', 'mb');
			$query = "SELECT * FROM mb_products";
			foreach($this->dbh->FetchResults($query) as $row)
			{
				$p = new SB_MBProduct();
				$p->SetDbData($row);
				$products[] = $p;
			}
		}
		ini_set('display_errors', 0);
		sb_include_lib('php-barcode/BarcodeGenerator.php');
		sb_include_lib('php-barcode/BarcodeGeneratorJPG.php');
		sb_include_lib('php-barcode/BarcodeGeneratorSVG.php');
		sb_include_lib('php-barcode/BarcodeGeneratorHTML.php');
		$generatorHTML = new Picqer\Barcode\BarcodeGeneratorJPG();
		$pdf = mb_get_pdf_instance($title);
		ob_start();
		include 'views/admin/reports/labels.php';
		$html = ob_get_clean();
		//die($html);
		
		$pdf->AddPage();
		$pdf->writeHTML($html, true, false, true, false, '');
		$pdf->Output(sprintf(__('products-catalog-%s.pdf'), sb_format_date(date('Y-m-d'))), 'I');
		die();
	}
	public function task_batch()
	{
		$action = SB_Request::getString('action');
		$ids	= SB_Request::getVar('ids');
		if( $action == 'delete' )
		{
			$ids_str = implode(',', $ids);
			$this->dbh->Query("DELETE FROM mb_product_meta WHERE product_id IN($ids_str)");
			$this->dbh->Query("DELETE FROM mb_product2category WHERE product_id IN($ids_str)");
			$this->dbh->Query("DELETE FROM mb_product2suppliers WHERE product_id IN($ids_str)");
			$this->dbh->Query("DELETE FROM mb_product2tag WHERE product_id IN($ids_str)");
			$this->dbh->Query("DELETE FROM mb_products WHERE product_id IN($ids_str)");
			SB_MessagesStack::AddMessage(__('The products has been deleted', 'mb'), 'success');
			sb_redirect(isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : SB_Route::_('index.php?mod=mb'));
		}
	}
}