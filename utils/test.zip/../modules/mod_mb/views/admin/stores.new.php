<?php
?>
<div class="wrap">
	<h2 id="page-title"><?php print $page_title; ?></h2>
	<form action="" method="post">
		<input type="hidden" name="mod" value="mb" />
		<input type="hidden" name="task" value="stores.save" />
		<?php if( isset($the_store) ): ?>
		<input type="hidden" name="store_id" value="<?php print $the_store->store_id; ?>" />
		<?php endif; ?>
		<div class="form-group">
			<label><?php print SB_Text::_('Name', 'mb'); ?></label>
			<input type="text" name="store_name" value="<?php print isset($the_store) ? $the_store->store_name:'';?>" class="form-control" />
		</div>
		<div class="form-group">
			<label><?php print SB_Text::_('Address', 'mb'); ?></label>
			<textarea name="store_address" class="form-control"><?php print isset($the_store) ? $the_store->store_address:'';?></textarea>
		</div>
		<div class="form-group">
			<label><?php print SB_Text::_('Phone', 'mb'); ?></label>
			<input type="text" name="store_phone" value="<?php print isset($the_store) ? $the_store->phone : ''; ?>" class="form-control" />
		</div>
		<h3><?php _e('Transaction Assignment', 'mb'); ?></h3>
		<div class="row">
			<div class="col-md-3">
				<div class="form-group">
					<label><?php _e('Sale', 'mb'); ?></label>
					<select name="meta[_sale_tt_id]" class="form-control">
						<option value="-1"><?php _e('-- transaction type --', 'mb'); ?></option>
						<?php foreach($ttypes as $tt): if($tt->in_out != 'out' ) continue;?>
						<option value="<?php print $tt->transaction_type_id; ?>" 
							<?php print isset($the_store) && $the_store->_sale_tt_id == $tt->transaction_type_id ? 'selected' : ''; ?>>
							<?php printf("%s - %s", $tt->transaction_key, $tt->transaction_name); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label><?php _e('Purchase', 'mb'); ?></label>
					<select name="meta[_purchase_tt_id]" class="form-control">
						<option value="-1"><?php _e('-- transaction type --', 'mb'); ?></option>
						<?php foreach($ttypes as $tt): if($tt->in_out != 'in' ) continue;?>
						<option value="<?php print $tt->transaction_type_id; ?>"
							<?php print isset($the_store) && $the_store->_purchase_tt_id == $tt->transaction_type_id ? 'selected' : ''; ?>>
							<?php printf("%s - %s", $tt->transaction_key, $tt->transaction_name); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label><?php _e('Input Transfer', 'mb'); ?></label>
					<select name="meta[_transfer_tt_id]" class="form-control">
						<option value="-1"><?php _e('-- transaction type --', 'mb'); ?></option>
						<?php foreach($ttypes as $tt): ?>
						<option value="<?php print $tt->transaction_type_id; ?>"
							<?php print isset($the_store) && $the_store->_transfer_tt_id == $tt->transaction_type_id ? 'selected' : ''; ?>>
							<?php printf("%s - %s", $tt->transaction_key, $tt->transaction_name); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label><?php _e('Output Transfer', 'mb'); ?></label>
					<select name="meta[_transfer_out_tt_id]" class="form-control">
						<option value="-1"><?php _e('-- transaction type --', 'mb'); ?></option>
						<?php foreach($ttypes as $tt): ?>
						<option value="<?php print $tt->transaction_type_id; ?>"
							<?php print isset($the_store) && $the_store->_transfer_out_tt_id == $tt->transaction_type_id ? 'selected' : ''; ?>>
							<?php printf("%s - %s", $tt->transaction_key, $tt->transaction_name); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
			<?php SB_Module::do_action('mb_store_form_transactions', isset($the_store) ? $the_store : null, $ttypes); ?>
		</div>
		<div class="form-group">
			<a class="btn btn-danger" href="<?php print SB_Route::_('index.php?mod=mb&view=stores.default')?>">
				<?php print SB_Text::_('Cancel', 'mb'); ?>
			</a>
			<button type="submit" class="btn btn-success"><?php print SB_Text::_('Save', 'mb')?></button>
		</div>
	</form>
</div>