<?php
?>
<div class="wrap">
	<h2>
		<?php _e('Inputs', 'mb'); ?>
		<div class="pull-right">
			<a href="<?php print SB_Route::_('index.php?mod=mb&view=purchases.new'); ?>" class="btn btn-secondary"><?php print SBText::_('New Purchase', 'mb'); ?></a>
		</div>
	</h2>
	<div class="row">
		<form action="" method="get">
			<input type="hidden" name="mod" value="quotes" />
			<div class="col-md-7">
				<div class="form-group">
					<input type="text" name="keyword" value="" class="form-control" />
				</div>
			</div>
			<button type="submit" id="btn-search-quote" class="btn btn-secondary" title="<?php _e('Search quote', 'quotes'); ?>">
				<span class="glyphicon glyphicon-search"></span>
			</button>
		</form>
	</div>
	<table class="table">
	<thead>
	<tr>
		<th>#</th>
		<th><?php _e('Num.', 'mb'); ?></th>
		<th><?php _e('Date', 'mb'); ?></th>
		<th><?php print SBText::_('Store', 'mb'); ?></th>
		<th><?php print SBText::_('Provider', 'mb'); ?></th>
		<th><?php print SBText::_('Amount', 'mb'); ?></th>
		<th><?php print SBText::_('Status', 'mb'); ?></th>
		<th><?php print SBText::_('Actions', 'mb'); ?></th>
	</tr>
	</thead>
	<tbody>
	<?php if( is_array($purchases) ): $i = 1;foreach($purchases as $p): ?>
	<tr>
		<td class="text-center"><?php print $i; ?></td>
		<td class="text-center"><?php print $p->order_id; ?></td>
		<td class="text-right"><?php print sb_format_date($p->order_date); ?></td>
		<td><?php print $p->store_name; ?></td>
		<td><?php print $p->provider; ?></td>
		<td class="text-right"><?php print $p->total; ?></td>
		<td class="text-center">
			<?php
			$class = 'danger';
			$label = __('Unknow', 'mb');
			if( $p->status == 'void' )
			{
				$class = 'danger';
				$label = __('Void', 'quotes');
			}
			if( $p->status == 'created' )
			{
				$class = 'success';
				$label = __('Created', 'Created');
			}
			if( $p->status == 'complete' )
			{
				$class = 'success';
				$label = __('Completed', 'quotes');
			}
			if( $p->status == 'waiting_stock' )
			{
				$class = 'warning';
				$label = __('Waiting Stock', 'mb');
			}
			?>
			<label class="label label-<?php print $class; ?>"><?php print $label; ?></label>
		</td>
		<td>
			<?php if( $p->status != 'complete' ): ?>
			<a href="<?php print SB_Route::_('index.php?mod=mb&task=purchases.receive&id='.$p->order_id); ?>" class="btn btn-default"
				title="<?php _e('Receive', 'mb'); ?>">
				<span class="glyphicon glyphicon-cog"></span>
			</a>
			<?php endif; ?>
			<a href="<?php print SB_Route::_('index.php?mod=mb&task=purchases.edit&id='.$p->order_id); ?>" class="btn btn-default"
				title="<?php _e('Edit', 'mb'); ?>">
				<span class="glyphicon glyphicon-edit"></span>
			</a>
			<a href="<?php print SB_Route::_('index.php?mod=mb&task=purchases.delete&id='.$p->order_id); ?>" class="btn btn-default confirm" 
				data-message="<?php _e('Are you sure to delete the purchase?', 'mb'); ?>"
				title="<?php print SBText::_('Delete', 'mb'); ?>">
				<span class="glyphicon glyphicon-trash"></span>
			</a>
		</td>
	</tr>
	<?php $i++; endforeach; endif; ?>
	</tbody>
	</table>
	<script>
	jQuery(function()
	{
		jQuery('.print-quote').click(function()
		{
			if( jQuery('#quote-iframe').length > 0 )
			{
				jQuery('#quote-iframe').remove();
			}
			var iframe = jQuery('<iframe id="quote-iframe" src="'+this.href+'" style="display:none;"></iframe>');
			//window.iframe = iframe;
			jQuery('body').append(iframe);
			try
			{
				iframe.load(function()
				{
					if(iframe.get(0).contentWindow.mb_print)
						iframe.get(0).contentWindow.mb_print();
				});
				
			}
			catch(e)
			{
				alert(e);
			}
			
			return false;
		});
	});
	</script>
</div>