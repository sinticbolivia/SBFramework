<?php
?>
<div class="grid-layout">
	<?php foreach($products as $p): ?>
		<?php include 'grid_item.php';?>
	<?php endforeach; ?>
	<div class="clearfix"></div>
</div>