<?php
define('Bill Now', 'Facturar');
define('gp_invoices', 'Facturacion');