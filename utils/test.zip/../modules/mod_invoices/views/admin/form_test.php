<?php
?>
<div class="wrap">
	<h2><?php print $title; ?></h2>
	<?php print $obj->FormTest($test_url); ?>
</div>